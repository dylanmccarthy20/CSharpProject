DROP TABLE Reservations;
DROP TABLE Tables;
DROP TABLE Locations;
DROP TABLE ResTimes;

CREATE TABLE Locations
( LocCode CHAR(1),
 Description varchar(12),
 CONSTRAINT pk_Locations PRIMARY KEY(LocCode));

CREATE TABLE Tables
(TableNo numeric(3),
 LocCode char(1),
 People numeric (1),
 status char(1),
 CONSTRAINT pk_Tables PRIMARY KEY (TableNo),
 CONSTRAINT fk_Tables_Locs FOREIGN KEY(LocCode) REFERENCES Locations);

CREATE TABLE ResTimes
(ResTime CHAR(5),
CONSTRAINT pk_ResTimes PRIMARY Key(ResTime));

CREATE TABLE Reservations(
ResID numeric(5),
name varchar2(20)NOT NULL,
Phone numeric(10)NOT NULL,
TableNo numeric(3) NOT NULL,
ResDate date NOT NUll,
ResTime char(5) NOT NULL,
People numeric(1)NOT NULL,
billAmount decimal(6,2)NOT NULL,
status char(1) Default 'W',
CONSTRAINT pk_Reservations PRIMARY KEY (ResID),
CONSTRAINT fk_Reservations_ResTimes FOREIGN KEY(ResTime) REFERENCES ResTimes,
CONSTRAINT fk_Reservations_Tables Foreign Key (TableNo) REFERENCES Tables(TableNo));






