﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestResvSYS
{
    class DBConnect
    {
        public const String oraDB = "Data Source = localhost/orcl; User ID = C##User1; Password = oracle;";
    }
}
