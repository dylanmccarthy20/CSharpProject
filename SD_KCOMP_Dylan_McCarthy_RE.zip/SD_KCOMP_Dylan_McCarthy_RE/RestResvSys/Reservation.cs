﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace RestResvSYS
{
    class Reservations
    {
        private int ResID;
        private String Name;
        private int TableNo;
        private String ResDate;
        private String TimeRes;
        private int PhnNo;
        private int People;
        private decimal BillAmount;
        private String Status;
        public Reservations()
        {
            ResID = 0;
            Name = "";
            PhnNo = 0;
            BillAmount = 0;
            ResDate = "";
            TimeRes = "";
            TableNo = 0;
            People = 0;
            Status ="W";
        }
        public Reservations(int resID,String name, int tableNo, int PhnNo, String resDate,String timeRes,int people,decimal billAmount, String status)
        {
            this.ResID = resID;
            this.Name = name;
            this.PhnNo = PhnNo;
            this.BillAmount = billAmount;
            this.ResDate = resDate;
            this.TimeRes = timeRes;
            this.TableNo = tableNo;
            this.People = people;
            this.Status = status;
        }


        public int getResID()
        {
            return ResID;
        }
        public String getName()
        {
            return Name;
        }
        public  int getTableNo()
        {
            return TableNo;
        }
        public int getPhnNo()
        {
            return PhnNo;
        }
        public String getResDate()
        {
            return ResDate;
        }
        public String getTimeRes()
        {
            return TimeRes;
        }
        public Decimal getBillAmt()
        {
            return BillAmount;
        }
        public int getPeople()
        {
            return People;
        }
        public String getResStatus()
        {
            return Status;
        }

        //Setting the instance variables
 
        public void setResID(int newResID)
        {
            this.ResID = newResID;
        }
        public void setName(String newName)
        {
            this.Name = newName;
        }
        public void setPhnNo(int newPhnNo)
        {
            this.PhnNo = newPhnNo;
        }
        public void setTableNo(int newTblNo)
        {
            this.TableNo = newTblNo;
        }
        public void setBillAmt(decimal newBill)
        {
            this.BillAmount = newBill;
        }
        public void setPeople(int newPeople)
        {
            this.People = newPeople;
        }
        public void setResDate(String newDate)
        {
            this.ResDate = newDate;
        }
        public void setResTime(String newTime)
        {
            this.TimeRes = newTime;
        }
        public void setResStatus(String newStatus)
        {
            this.Status = newStatus;
        }



        public static int getNextResID()
        {
            int nextResID = 0;
            //Define SQL query to retrieve the last Id assigned
            String strSQL = "SELECT MAX(ResID) FROM Reservations";
            //Connect to the database
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //define an Oracle command
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            //execute the command using an Oracle DataReader
            OracleDataReader dr = cmd.ExecuteReader();
            dr.Read();
            //An aggregate function ALWAYS returns one record
            //which contains the largest WidgetId in the table OR NULL
            if (dr.IsDBNull(0))
                return nextResID = 1;
            else
                nextResID = dr.GetInt32(0) + 1;
            conn.Close();
            return nextResID;
        }
       
        public static DataSet getSeatsNum()
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT * FROM Tables";
            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            //Declare an Oracle DataAdapter
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            //Declare DataSet to return records to application
            DataSet dataSet = new DataSet();
            DataSet ds = dataSet;
            da.Fill(ds, "PP");
            //Close database connection
            conn.Close();
            return ds;
        }
        public static DataSet getArrTime()
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT ResTime FROM ResTimes";
            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            //Declare an Oracle DataAdapter
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            //Declare DataSet to return records to application
            DataSet dataSet = new DataSet();
            DataSet ds = dataSet;
            da.Fill(ds, "AT");
            //Close database connection
            conn.Close();
            return ds;
        }
        public void getRes(int resID)
        {
            //define Sql Query
            String strSQL = "SELECT * FROM Reservations WHERE ResID = " + resID;
            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            OracleDataReader dr = cmd.ExecuteReader();
            //read the record returned in dr and use values to instantiate the object
            dr.Read();
            /*int resID//,String name//, int tableNo, int PhnNo, String resDate,String timeRes,int people,decimal billAmount, String status*/
            
    
            this.ResID = dr.GetInt32(0);
            this.Name = dr.GetString(1);
            this.PhnNo = dr.GetInt32(2);
            this.TableNo = dr.GetInt32(3);
            this.ResDate = dr.GetString(4);
            this.TimeRes = dr.GetString(5);
            this.People = dr.GetInt32(6);
            this.BillAmount = dr.GetDecimal(7);
            this.Status = dr.GetString(8);

            //close database connection
            conn.Close();

        }
        public void makeRes()
        {
            //define Sql Query
            String strSQL = "INSERT INTO Reservations VALUES(" + this.ResID + ",'" +
            this.Name + "','" + this.PhnNo + "'," + this.TableNo + ",'" +
            this.ResDate + "','" + this.TimeRes + "'," + this.People + "," + this.BillAmount + ",'" + this.Status + "')";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public static DataSet getSummaryRes()
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT * FROM Reservations WHERE status='W' ORDER BY ResID";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            //Declare an Oracle DataAdapter
            OracleDataAdapter da = new OracleDataAdapter(cmd);

            //Declare DataSet to return records to application
            DataSet ds = new DataSet();
            da.Fill(ds, "SR");
            //Close database connection
            conn.Close();
            return ds;
        }
        public void removeRes()
        {
            //define Sql Query
            String strSQL = "Update Reservations SET status = '" + this.Status +
             "' WHERE ResID = " + this.ResID;

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            cmd.ExecuteNonQuery();

            conn.Close();
        }
        public void CheckInRes()
        {
            //define Sql Query
            String strSQL = "Update Reservations SET status = '" + this.Status +
             "' WHERE ResID = " + this.ResID;

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            cmd.ExecuteNonQuery();

            conn.Close();
        }

        public void PayBillRes()
        {
            //define Sql Query
            String strSQL = "Update Reservations SET status = '" + this.Status +
             "', BillAmount=" + this.BillAmount + " WHERE ResID = " + this.ResID;

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            cmd.ExecuteNonQuery();

            conn.Close();
        }

        public static DataSet getAvailableTables(String resDate, int people)
        {
            //define Sql Query
            String strSQL = "SELECT * FROM Tables WHERE people >="+ people +
                " AND TableNo NOT IN (SELECT TableNo FROM Reservations WHERE resDate='"+ resDate + "') " 
                +"ORDER BY TableNo";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet();

            da.Fill(ds,"AT");
            conn.Close();

            return ds;
        }

        public static DataTable getYearlyReservations(String Year)
        {
            //define Sql Query
             String strSQL="SELECT T.People, COUNT(*) FROM Reservations R JOIN Tables T ON T.TableNo = R.TableNo" +
                " WHERE ResDate LIKE '%" + Year + "' GROUP BY T.People    ORDER BY T.People";

            DataTable dt = new DataTable();

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            OracleDataAdapter da = new OracleDataAdapter(cmd);

            da.Fill(dt);
            conn.Close();

            return dt;
        }

        public static DataTable getYearlyRevenue(String Year)
        {
            //define Sql Query
            String strSQL = "SELECT to_Char (resDate,'MM') AS Year, SUM (billAmount) AS TOTAL FROM Reservations" +
                " WHERE resDate LIKE '%"+ Year + "' GROUP BY to_Char(resDate, 'MM')" +
                " ORDER BY to_Char (resDate,'MM') ";
            
            DataTable dt = new DataTable();
   
            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            OracleDataAdapter da = new OracleDataAdapter(cmd);

            da.Fill(dt);
            conn.Close();

            return dt;
        }

    }
}
