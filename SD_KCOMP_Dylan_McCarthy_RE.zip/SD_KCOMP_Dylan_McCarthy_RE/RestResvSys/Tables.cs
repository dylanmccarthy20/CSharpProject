﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace RestResvSYS
{

    class Tables
    {

        private int tableNo;
        private String locCode;
        private int seatsNum;
        private String status;

        public static object aTable { get; internal set; }

        public Tables()
        {
            tableNo = 0;
            locCode = "";
            seatsNum = 0;
            status = "";
        }
        public Tables(int TNo, String Loc, int Seats, String Status)
        {
            this.tableNo = TNo;
            this.locCode = Loc;
            this.seatsNum = Seats;
            this.status = Status;
        }

        public int getTableNo()
        {
            return tableNo;
        }
        public String getLocCode()
        {
            return locCode;
        }
        public int getSeatsNum()
        {
            return seatsNum;
        }
        public String getStatus()
        {
            return status;
        }

        //Setting the instance variables
        public void setTableNo(int newTblNo)
        {
            this.tableNo = newTblNo;
        }

        public void setLocCode(String newLocCode)
        {
            this.locCode = newLocCode;
        }


        public void setSeatsNum(int newSeatsNum)
        {
            this.seatsNum = newSeatsNum;
        }

        public void setStatus(String newStatus)
        {
            this.status = newStatus;
        }

        public void getTable(int tableNo)
        {
            //define Sql Query
            String strSQL = "SELECT * FROM Tables WHERE TableNo = " + tableNo;
            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            OracleDataReader dr = cmd.ExecuteReader();
            //read the record returned in dr and use values to instantiate the object
            dr.Read();
            this.tableNo = dr.GetInt32(0);
            this.locCode = dr.GetString(1);
            this.seatsNum = dr.GetInt32(2);
            this.status = dr.GetString(3);
            //close database connection
            conn.Close();
        }

        public void getTableStatus(int tableNo)
        {
            //define Sql Query
            String strSQL = "SELECT Status FROM Tables WHERE TableNo = " + tableNo;
            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            OracleDataReader dr = cmd.ExecuteReader();
            //read the record returned in dr and use values to instantiate the object
            dr.Read();
            this.tableNo = dr.GetInt32(0);
            this.locCode = dr.GetString(1);
            this.seatsNum = dr.GetInt32(2);
            this.status = dr.GetString(3);
            //close database connection
            conn.Close();
        }

        public static int getNextTable()
        {
            int nextTable = 0;
            //Define SQL query to retrieve the last Id assigned
            String strSQL = "SELECT MAX(tableNo) FROM Tables";
            //Connect to the database
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //define an Oracle command
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            //execute the command using an Oracle DataReader
            OracleDataReader dr = cmd.ExecuteReader();
            dr.Read();
            //An aggregate function ALWAYS returns one record
            //which contains the largest WidgetId in the table OR NULL
            if (dr.IsDBNull(0))
                return nextTable = 1;
            else
                nextTable = dr.GetInt32(0) + 1;
            conn.Close();
            return nextTable;
        }

        public static DataSet getSummaryTables()
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT * FROM Tables WHERE status='A' ORDER BY TableNo";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            //Declare an Oracle DataAdapter
            OracleDataAdapter da = new OracleDataAdapter(cmd);

            //Declare DataSet to return records to application
            DataSet ds = new DataSet();
            da.Fill(ds, "TO");
            //Close database connection
            conn.Close();
            return ds;
        }


        public void addTable()
        {
            //define Sql Query
            String strSQL = "INSERT INTO Tables VALUES (" + this.tableNo +
             ",'" + this.locCode + "'," + this.seatsNum + ",'" +
            this.status + "')";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }


        public void updateTable()
        {
            //define Sql Query
            String strSQL = "Update Tables SET LocCode = '" + this.locCode.Substring(0, 1) + "', People = " + this.seatsNum +
             " WHERE TableNo = " + this.tableNo;

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            cmd.ExecuteNonQuery();

            conn.Close();
        }

        public void removeTable()
        {
            //define Sql Query
            String strSQL = "Update Tables SET status = '" + this.status + 
             "' WHERE TableNo = " + this.tableNo; 

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            cmd.ExecuteNonQuery();

            conn.Close();
        }


    }
}
