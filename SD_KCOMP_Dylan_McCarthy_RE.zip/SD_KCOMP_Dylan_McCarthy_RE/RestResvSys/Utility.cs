﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestResvSYS
{
    class Utility
    {
        public static void LoadPeople(ComboBox cboName)
        {
             //load combo with seat numbers
            for (int i = 1; i < 10; i++)
            {
                cboName.Items.Add(i.ToString());
            }

        }

        public static DataSet getSeatsNum()
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT People FROM Tables";
            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            //Declare an Oracle DataAdapter
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            //Declare DataSet to return records to application
            DataSet ds = new DataSet();

            da.Fill(ds, "SN");
            //Close database connection
            conn.Close();
            return ds;
        }
        
        public static void ArrTime_Load(ComboBox cboTimes)
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT ResTime FROM ResTimes";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            //Declare an Oracle DataReader
            OracleDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cboTimes.Items.Add(dr.GetString(0));
            }

            //Close database connection
            conn.Close();
        }
        public static void cboNameLoad(ComboBox cboNames)
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT Name FROM Reservations";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            //Declare an Oracle DataReader
            OracleDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cboNames.Items.Add(dr.GetString(0));
            }

            //Close database connection
            conn.Close();
        }
    

        public static void cboResDate(ComboBox cboDate)
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT ResDate FROM Reservations";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            //Declare an Oracle DataReader
            OracleDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cboDate.Items.Add(dr.GetString(0));
            }

            //Close database connection
            conn.Close();
        }

        public static void cboTableLoad(ComboBox cboTableNo)
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT TableNo FROM Tables";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            //Declare an Oracle DataReader
            OracleDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cboTableNo.Items.Add(dr.GetString(0));
            }

            //Close database connection
            conn.Close();
        }

        public static void cboPhoneLoad(ComboBox cboPhoneNo)
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT Phone FROM Reservations";

            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();

            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);

            //Declare an Oracle DataReader
            OracleDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cboPhoneNo.Items.Add(dr.GetString(0));
            }

            //Close database connection
            conn.Close();
        }

        public static void LoadLocs(ComboBox cboName)
            {
                //define Sql Query to get summary of available widgets
                String strSQL = "SELECT * FROM Locations ORDER BY LocCode";

                //Declare an Oracle Connection
                OracleConnection conn = new OracleConnection(DBConnect.oraDB);
                conn.Open();

                //declare an Oracle Command to execute
                OracleCommand cmd = new OracleCommand(strSQL, conn);

                //Declare an Oracle DataReader
                OracleDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cboName.Items.Add(dr.GetString(0) + " " + dr.GetString(1));
                }

                //Close database connection
                conn.Close();
            }


        public static DataSet FindTable()
        {
            //define Sql Query to get summary of available widgets
            String strSQL = "SELECT * FROM Tables WHERE ";
            //Declare an Oracle Connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            conn.Open();
            //declare an Oracle Command to execute
            OracleCommand cmd = new OracleCommand(strSQL, conn);
            //Declare an Oracle DataAdapter
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            //Declare DataSet to return records to application
            DataSet ds = new DataSet();

            da.Fill(ds, "SN");
            //Close database connection
            conn.Close();
            return ds;
        }

        public static void loadYears(ComboBox cboName)
        {
            int year = DateTime.Now.Year;

            for (int i = 1; i < 5; i++)
            {
                cboName.Items.Add(year.ToString());
                year = year - 1;
            }
        }

    }
}

