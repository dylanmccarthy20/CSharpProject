﻿
namespace RestResvSYS
{
    partial class frmAddTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddTable));
            this.mnuAddTbl = new System.Windows.Forms.MenuStrip();
            this.exitToolAddTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.backToMainMenuAddTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.grpBoxAddTbl = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.cboLocCode = new System.Windows.Forms.ComboBox();
            this.cboPeople = new System.Windows.Forms.ComboBox();
            this.lblAddTblLocation = new System.Windows.Forms.Label();
            this.lblPeople = new System.Windows.Forms.Label();
            this.lblAddTblNo = new System.Windows.Forms.Label();
            this.txtTableNo = new System.Windows.Forms.TextBox();
            this.mnuAddTbl.SuspendLayout();
            this.grpBoxAddTbl.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuAddTbl
            // 
            this.mnuAddTbl.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.mnuAddTbl.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.mnuAddTbl.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolAddTbl,
            this.backToMainMenuAddTbl});
            this.mnuAddTbl.Location = new System.Drawing.Point(0, 0);
            this.mnuAddTbl.Name = "mnuAddTbl";
            this.mnuAddTbl.Size = new System.Drawing.Size(800, 33);
            this.mnuAddTbl.TabIndex = 0;
            this.mnuAddTbl.Text = "menuStrip1";
            // 
            // exitToolAddTbl
            // 
            this.exitToolAddTbl.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitToolAddTbl.Name = "exitToolAddTbl";
            this.exitToolAddTbl.Size = new System.Drawing.Size(55, 29);
            this.exitToolAddTbl.Text = "Exit";
            this.exitToolAddTbl.Click += new System.EventHandler(this.exitToolAddTbl_Click);
            // 
            // backToMainMenuAddTbl
            // 
            this.backToMainMenuAddTbl.Name = "backToMainMenuAddTbl";
            this.backToMainMenuAddTbl.Size = new System.Drawing.Size(180, 29);
            this.backToMainMenuAddTbl.Text = "Back to Main Menu";
            this.backToMainMenuAddTbl.Click += new System.EventHandler(this.backToMainMenuAddTbl_Click);
            // 
            // grpBoxAddTbl
            // 
            this.grpBoxAddTbl.Controls.Add(this.btnAdd);
            this.grpBoxAddTbl.Controls.Add(this.cboLocCode);
            this.grpBoxAddTbl.Controls.Add(this.cboPeople);
            this.grpBoxAddTbl.Controls.Add(this.lblAddTblLocation);
            this.grpBoxAddTbl.Controls.Add(this.lblPeople);
            this.grpBoxAddTbl.Controls.Add(this.lblAddTblNo);
            this.grpBoxAddTbl.Controls.Add(this.txtTableNo);
            this.grpBoxAddTbl.Location = new System.Drawing.Point(46, 64);
            this.grpBoxAddTbl.Name = "grpBoxAddTbl";
            this.grpBoxAddTbl.Size = new System.Drawing.Size(700, 331);
            this.grpBoxAddTbl.TabIndex = 1;
            this.grpBoxAddTbl.TabStop = false;
            this.grpBoxAddTbl.Text = "Please enter the details";
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(182, 222);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(142, 46);
            this.btnAdd.TabIndex = 11;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // cboLocCode
            // 
            this.cboLocCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLocCode.FormattingEnabled = true;
            this.cboLocCode.Location = new System.Drawing.Point(182, 150);
            this.cboLocCode.Name = "cboLocCode";
            this.cboLocCode.Size = new System.Drawing.Size(216, 28);
            this.cboLocCode.TabIndex = 8;
            // 
            // cboPeople
            // 
            this.cboPeople.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPeople.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPeople.FormattingEnabled = true;
            this.cboPeople.Location = new System.Drawing.Point(182, 101);
            this.cboPeople.Name = "cboPeople";
            this.cboPeople.Size = new System.Drawing.Size(216, 28);
            this.cboPeople.TabIndex = 7;
            // 
            // lblAddTblLocation
            // 
            this.lblAddTblLocation.AutoSize = true;
            this.lblAddTblLocation.Location = new System.Drawing.Point(70, 150);
            this.lblAddTblLocation.Name = "lblAddTblLocation";
            this.lblAddTblLocation.Size = new System.Drawing.Size(78, 20);
            this.lblAddTblLocation.TabIndex = 6;
            this.lblAddTblLocation.Text = "Location: ";
            // 
            // lblPeople
            // 
            this.lblPeople.AutoSize = true;
            this.lblPeople.Location = new System.Drawing.Point(15, 109);
            this.lblPeople.Name = "lblPeople";
            this.lblPeople.Size = new System.Drawing.Size(140, 20);
            this.lblPeople.TabIndex = 5;
            this.lblPeople.Text = "Number of People:";
            // 
            // lblAddTblNo
            // 
            this.lblAddTblNo.AutoSize = true;
            this.lblAddTblNo.Location = new System.Drawing.Point(34, 57);
            this.lblAddTblNo.Name = "lblAddTblNo";
            this.lblAddTblNo.Size = new System.Drawing.Size(114, 20);
            this.lblAddTblNo.TabIndex = 4;
            this.lblAddTblNo.Text = "Table number: ";
            // 
            // txtTableNo
            // 
            this.txtTableNo.Enabled = false;
            this.txtTableNo.Location = new System.Drawing.Point(182, 54);
            this.txtTableNo.MaxLength = 2;
            this.txtTableNo.Name = "txtTableNo";
            this.txtTableNo.ReadOnly = true;
            this.txtTableNo.Size = new System.Drawing.Size(49, 26);
            this.txtTableNo.TabIndex = 0;
            // 
            // frmAddTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 449);
            this.Controls.Add(this.grpBoxAddTbl);
            this.Controls.Add(this.mnuAddTbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mnuAddTbl;
            this.Name = "frmAddTable";
            this.Text = "Add Table";
            this.Load += new System.EventHandler(this.frmAddTable_Load);
            this.mnuAddTbl.ResumeLayout(false);
            this.mnuAddTbl.PerformLayout();
            this.grpBoxAddTbl.ResumeLayout(false);
            this.grpBoxAddTbl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuAddTbl;
        private System.Windows.Forms.ToolStripMenuItem exitToolAddTbl;
        private System.Windows.Forms.ToolStripMenuItem backToMainMenuAddTbl;
        private System.Windows.Forms.GroupBox grpBoxAddTbl;
        private System.Windows.Forms.Label lblAddTblLocation;
        private System.Windows.Forms.Label lblPeople;
        private System.Windows.Forms.Label lblAddTblNo;
        private System.Windows.Forms.TextBox txtTableNo;
        private System.Windows.Forms.ComboBox cboLocCode;
        private System.Windows.Forms.ComboBox cboPeople;
        private System.Windows.Forms.Button btnAdd;
    }
}