﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestResvSYS
{
    public partial class frmAddTable : Form
    {
        DataSet ds = new DataSet();
        frmMainMenu parent;

        public frmAddTable()
        {
            InitializeComponent();
        }

        public frmAddTable(frmMainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }

        private void exitToolAddTbl_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to exit the system","Exiting The System",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Information);
            if(choice==DialogResult.Yes)
            Application.Exit();
        }

        private void backToMainMenuAddTbl_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
            
        }      

        private void frmAddTable_Load(object sender, EventArgs e)
        {
           //gets Largest TableNo value and increments that value
            txtTableNo.Text = Tables.getNextTable().ToString("000");
            
            //loads data from the Utility class for cboSeats and cboLocCode
            Utility.LoadPeople(cboPeople);
            Utility.LoadLocs(cboLocCode);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //validate data
            if (txtTableNo.Text.Equals(""))
            {
                MessageBox.Show("Table number must be entered", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTableNo.Focus();
                return;
            }

            if (cboPeople.SelectedIndex == -1)
            {
                MessageBox.Show("People must be entered", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboPeople.Focus();
                return;
            }
            if (cboLocCode.SelectedIndex == -1)
            {
                MessageBox.Show("Location must be entered", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboPeople.Focus();
                return;
            }

            //Save data
            Tables aTable = new Tables(Convert.ToInt32(txtTableNo.Text),
            cboLocCode.Text.Substring(0, 1), Convert.ToInt32(cboPeople.Text), "A");
            aTable.addTable();
            //display confirmation message
            MessageBox.Show("Table is added", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //reset UI
            txtTableNo.Text = Tables.getNextTable().ToString("000");
            cboLocCode.SelectedIndex = -1;
            cboPeople.SelectedIndex = -1;
            cboLocCode.Focus();

        }
    }
}
