﻿
namespace RestResvSYS
{
    partial class frmCancelRes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCancelRes));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BTMnuCnclRes = new System.Windows.Forms.ToolStripMenuItem();
            this.exitTlStripCnclRes = new System.Windows.Forms.ToolStripMenuItem();
            this.grpRemResTables = new System.Windows.Forms.GroupBox();
            this.cboDate = new System.Windows.Forms.ComboBox();
            this.cboPhone = new System.Windows.Forms.ComboBox();
            this.cboName = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboPeople = new System.Windows.Forms.ComboBox();
            this.lblAddTblSize = new System.Windows.Forms.Label();
            this.btnCancelRes = new System.Windows.Forms.Button();
            this.lblPhoneNo = new System.Windows.Forms.Label();
            this.lblResName = new System.Windows.Forms.Label();
            this.cboTables = new System.Windows.Forms.ComboBox();
            this.lblRemTblRes = new System.Windows.Forms.Label();
            this.lblArrTime = new System.Windows.Forms.Label();
            this.cboArrTime = new System.Windows.Forms.ComboBox();
            this.cboRemResID = new System.Windows.Forms.ComboBox();
            this.lblRemRes = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpMakeRes = new System.Windows.Forms.GroupBox();
            this.menuStrip1.SuspendLayout();
            this.grpRemResTables.SuspendLayout();
            this.grpMakeRes.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMnuCnclRes,
            this.exitTlStripCnclRes});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1051, 33);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // BTMnuCnclRes
            // 
            this.BTMnuCnclRes.Name = "BTMnuCnclRes";
            this.BTMnuCnclRes.Size = new System.Drawing.Size(180, 29);
            this.BTMnuCnclRes.Text = "Back to Main Menu";
            this.BTMnuCnclRes.Click += new System.EventHandler(this.BTMnuCnclRes_Click);
            // 
            // exitTlStripCnclRes
            // 
            this.exitTlStripCnclRes.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitTlStripCnclRes.Name = "exitTlStripCnclRes";
            this.exitTlStripCnclRes.Size = new System.Drawing.Size(55, 29);
            this.exitTlStripCnclRes.Text = "Exit";
            this.exitTlStripCnclRes.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.exitTlStripCnclRes.Click += new System.EventHandler(this.exitTlStripCnclRes_Click);
            // 
            // grpRemResTables
            // 
            this.grpRemResTables.Controls.Add(this.cboDate);
            this.grpRemResTables.Controls.Add(this.cboPhone);
            this.grpRemResTables.Controls.Add(this.cboName);
            this.grpRemResTables.Controls.Add(this.label2);
            this.grpRemResTables.Controls.Add(this.cboPeople);
            this.grpRemResTables.Controls.Add(this.lblAddTblSize);
            this.grpRemResTables.Controls.Add(this.btnCancelRes);
            this.grpRemResTables.Controls.Add(this.lblPhoneNo);
            this.grpRemResTables.Controls.Add(this.lblResName);
            this.grpRemResTables.Controls.Add(this.cboTables);
            this.grpRemResTables.Controls.Add(this.lblRemTblRes);
            this.grpRemResTables.Controls.Add(this.lblArrTime);
            this.grpRemResTables.Controls.Add(this.cboArrTime);
            this.grpRemResTables.Location = new System.Drawing.Point(21, 247);
            this.grpRemResTables.Name = "grpRemResTables";
            this.grpRemResTables.Size = new System.Drawing.Size(954, 262);
            this.grpRemResTables.TabIndex = 22;
            this.grpRemResTables.TabStop = false;
            this.grpRemResTables.Text = "Please enter the details:";
            this.grpRemResTables.Visible = false;
            // 
            // cboDate
            // 
            this.cboDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDate.FormattingEnabled = true;
            this.cboDate.Location = new System.Drawing.Point(437, 160);
            this.cboDate.Name = "cboDate";
            this.cboDate.Size = new System.Drawing.Size(127, 28);
            this.cboDate.TabIndex = 36;
            // 
            // cboPhone
            // 
            this.cboPhone.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhone.FormattingEnabled = true;
            this.cboPhone.Location = new System.Drawing.Point(135, 96);
            this.cboPhone.Name = "cboPhone";
            this.cboPhone.Size = new System.Drawing.Size(142, 28);
            this.cboPhone.TabIndex = 35;
            // 
            // cboName
            // 
            this.cboName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboName.FormattingEnabled = true;
            this.cboName.Location = new System.Drawing.Point(135, 29);
            this.cboName.Name = "cboName";
            this.cboName.Size = new System.Drawing.Size(142, 28);
            this.cboName.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(243, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "Date Of Reservation: ";
            // 
            // cboPeople
            // 
            this.cboPeople.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPeople.FormattingEnabled = true;
            this.cboPeople.Location = new System.Drawing.Point(149, 165);
            this.cboPeople.Name = "cboPeople";
            this.cboPeople.Size = new System.Drawing.Size(64, 28);
            this.cboPeople.TabIndex = 30;
            // 
            // lblAddTblSize
            // 
            this.lblAddTblSize.AutoSize = true;
            this.lblAddTblSize.Location = new System.Drawing.Point(62, 168);
            this.lblAddTblSize.Name = "lblAddTblSize";
            this.lblAddTblSize.Size = new System.Drawing.Size(58, 20);
            this.lblAddTblSize.TabIndex = 29;
            this.lblAddTblSize.Text = "People";
            // 
            // btnCancelRes
            // 
            this.btnCancelRes.Location = new System.Drawing.Point(727, 86);
            this.btnCancelRes.Name = "btnCancelRes";
            this.btnCancelRes.Size = new System.Drawing.Size(155, 38);
            this.btnCancelRes.TabIndex = 28;
            this.btnCancelRes.Text = "Cancel Reservation";
            this.btnCancelRes.UseVisualStyleBackColor = true;
            this.btnCancelRes.Click += new System.EventHandler(this.btnCancelRes_Click_1);
            // 
            // lblPhoneNo
            // 
            this.lblPhoneNo.AutoSize = true;
            this.lblPhoneNo.Location = new System.Drawing.Point(6, 102);
            this.lblPhoneNo.Name = "lblPhoneNo";
            this.lblPhoneNo.Size = new System.Drawing.Size(123, 20);
            this.lblPhoneNo.TabIndex = 25;
            this.lblPhoneNo.Text = "Phone Number: ";
            // 
            // lblResName
            // 
            this.lblResName.AutoSize = true;
            this.lblResName.Location = new System.Drawing.Point(61, 35);
            this.lblResName.Name = "lblResName";
            this.lblResName.Size = new System.Drawing.Size(59, 20);
            this.lblResName.TabIndex = 23;
            this.lblResName.Text = "Name: ";
            // 
            // cboTables
            // 
            this.cboTables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTables.FormattingEnabled = true;
            this.cboTables.Location = new System.Drawing.Point(437, 32);
            this.cboTables.Name = "cboTables";
            this.cboTables.Size = new System.Drawing.Size(142, 28);
            this.cboTables.TabIndex = 22;
            // 
            // lblRemTblRes
            // 
            this.lblRemTblRes.AutoSize = true;
            this.lblRemTblRes.Location = new System.Drawing.Point(308, 37);
            this.lblRemTblRes.Name = "lblRemTblRes";
            this.lblRemTblRes.Size = new System.Drawing.Size(97, 20);
            this.lblRemTblRes.TabIndex = 21;
            this.lblRemTblRes.Text = "Select Table";
            // 
            // lblArrTime
            // 
            this.lblArrTime.AutoSize = true;
            this.lblArrTime.Location = new System.Drawing.Point(358, 96);
            this.lblArrTime.Name = "lblArrTime";
            this.lblArrTime.Size = new System.Drawing.Size(47, 20);
            this.lblArrTime.TabIndex = 20;
            this.lblArrTime.Text = "Time:";
            // 
            // cboArrTime
            // 
            this.cboArrTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboArrTime.FormattingEnabled = true;
            this.cboArrTime.Location = new System.Drawing.Point(437, 96);
            this.cboArrTime.Name = "cboArrTime";
            this.cboArrTime.Size = new System.Drawing.Size(85, 28);
            this.cboArrTime.TabIndex = 19;
            // 
            // cboRemResID
            // 
            this.cboRemResID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRemResID.FormattingEnabled = true;
            this.cboRemResID.Location = new System.Drawing.Point(197, 63);
            this.cboRemResID.Name = "cboRemResID";
            this.cboRemResID.Size = new System.Drawing.Size(142, 28);
            this.cboRemResID.TabIndex = 23;
            this.cboRemResID.SelectedIndexChanged += new System.EventHandler(this.cboRemResID_SelectedIndexChanged);
            // 
            // lblRemRes
            // 
            this.lblRemRes.AutoSize = true;
            this.lblRemRes.Location = new System.Drawing.Point(28, 66);
            this.lblRemRes.Name = "lblRemRes";
            this.lblRemRes.Size = new System.Drawing.Size(127, 20);
            this.lblRemRes.TabIndex = 4;
            this.lblRemRes.Text = "Reservation ID : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(327, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 12;
            // 
            // grpMakeRes
            // 
            this.grpMakeRes.Controls.Add(this.cboRemResID);
            this.grpMakeRes.Controls.Add(this.label1);
            this.grpMakeRes.Controls.Add(this.lblRemRes);
            this.grpMakeRes.Location = new System.Drawing.Point(31, 61);
            this.grpMakeRes.Name = "grpMakeRes";
            this.grpMakeRes.Size = new System.Drawing.Size(516, 162);
            this.grpMakeRes.TabIndex = 23;
            this.grpMakeRes.TabStop = false;
            this.grpMakeRes.Text = "Please enter the details";
            // 
            // frmCancelRes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 552);
            this.Controls.Add(this.grpMakeRes);
            this.Controls.Add(this.grpRemResTables);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCancelRes";
            this.Text = "Cancel Reservation";
            this.Load += new System.EventHandler(this.frmCancelRes_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpRemResTables.ResumeLayout(false);
            this.grpRemResTables.PerformLayout();
            this.grpMakeRes.ResumeLayout(false);
            this.grpMakeRes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BTMnuCnclRes;
        private System.Windows.Forms.ToolStripMenuItem exitTlStripCnclRes;
        private System.Windows.Forms.GroupBox grpRemResTables;
        private System.Windows.Forms.Button btnCancelRes;
        private System.Windows.Forms.Label lblPhoneNo;
        private System.Windows.Forms.Label lblResName;
        private System.Windows.Forms.Label lblRemTblRes;
        private System.Windows.Forms.Label lblArrTime;
        private System.Windows.Forms.Label lblRemRes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboPeople;
        private System.Windows.Forms.Label lblAddTblSize;
        private System.Windows.Forms.ComboBox cboRemResID;
        private System.Windows.Forms.ComboBox cboTables;
        private System.Windows.Forms.ComboBox cboArrTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpMakeRes;
        private System.Windows.Forms.ComboBox cboPhone;
        private System.Windows.Forms.ComboBox cboName;
        private System.Windows.Forms.ComboBox cboDate;
    }
}