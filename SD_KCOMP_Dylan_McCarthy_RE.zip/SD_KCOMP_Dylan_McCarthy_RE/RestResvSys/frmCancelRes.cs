﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestResvSYS
{
   
    public partial class frmCancelRes : Form
    {
        frmMainMenu parent;
        Reservations aRes = new Reservations();
        public frmCancelRes()
        {
            InitializeComponent();
        }
        public frmCancelRes(frmMainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }
        private void frmCancelRes_Load(object sender, EventArgs e)
        {
            loadRes();
        }
        private void loadRes()
        {

            //move records from ds into cboWidgets
            cboRemResID.Items.Clear();
            DataSet ds = Reservations.getSummaryRes();
           
            //load combo with stockNo and Description for all stock
            for (int i = 0; i < ds.Tables["SR"].Rows.Count; i++)
                cboRemResID.Items.Add(ds.Tables[0].Rows[i][0].ToString().PadLeft(3, '0') +
                " " + ds.Tables[0].Rows[i][1].ToString());

        }
        private void BTMnuCnclRes_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void exitTlStripCnclRes_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to exit the system", "Exiting The System", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (choice == DialogResult.Yes)
                Application.Exit();
        }


        private void cboRemResID_SelectedIndexChanged(object sender, EventArgs e)
        {

            //loads all data from the database in the comboboxes
            Utility.LoadPeople(cboPeople);
            Utility.ArrTime_Load(cboArrTime);
            Utility.cboNameLoad(cboName);
            Utility.cboTableLoad(cboTables);
            Utility.cboPhoneLoad(cboPhone);
            Utility.cboResDate(cboDate);
            
            aRes.getRes(Convert.ToInt32(cboRemResID.Text.Substring(0, 3)));
            
            //Set cboArrTime to current value.
            cboArrTime.SelectedIndex = 0;         

            String arrTime = aRes.getTimeRes();

            //this FOR loop finds the Arrival time that belongs to the resID selected
            for (int i = 0; !(cboArrTime.Text == arrTime); i++)
            {
                cboArrTime.SelectedIndex++;
            }

            //Set cboDate to current value.
            cboDate.SelectedIndex = 0;

            //this FOR loop finds the date that belongs to the resID selected
            for (int i = 0; !(cboDate.Text == aRes.getResDate()); i++)
            {
                cboDate.SelectedIndex++;
            }

            //Set cboName to current value.
            cboName.SelectedIndex = 0;

            //this FOR loop finds the Name that belongs to the resID selected
            for (int i = 0; !(cboName.Text == aRes.getName()); i++)
            {
                cboName.SelectedIndex++;
            }

            //Set cboPhone to current value.
            cboPhone.SelectedIndex = 0;

            for (int i = 0; !(Convert.ToInt32(cboPhone.Text) == aRes.getPhnNo()); i++)
            {
                cboPhone.SelectedIndex++;
            }

            //Set cboPeople to current value.
            cboPeople.SelectedIndex = 0;   

            //this FOR loop finds the people that belongs to the resID selected
            for (int i = 0; !(Convert.ToInt32(cboPeople.Text) == aRes.getPeople()); i++)
            {
                cboPeople.SelectedIndex++;
            }

            //Set cboTables to current value.
            cboTables.SelectedIndex = 0;

            //this FOR loop finds the table that belongs to the resID selected
            for (int i = 0; !(Convert.ToInt32(cboTables.Text) == aRes.getTableNo()); i++)
            {
                cboTables.SelectedIndex++;
            }

            //Setting cboTime to current value
            cboArrTime.SelectedIndex = 0;

            //makes the remove table visible when index changed
            grpRemResTables.Visible = true;

            aRes.getRes(Convert.ToInt32(cboRemResID.Text.Substring(0, 3)));

        }

        private void btnCancelRes_Click(object sender, EventArgs e)
        {

            //NO data to validate

            // Update data in Tables File
            //Instantiate an instance of a Table with values in form controls
            aRes.setResStatus("C");

            //Invoke The updateTable() method
            aRes.removeRes();

            //display confirmation message
            MessageBox.Show("Table is removed", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //reset UI
                cboPhone.SelectedIndex = 0;
                cboName.SelectedIndex = 0;
                grpRemResTables.Visible = false;
                cboRemResID.SelectedIndex = -1;
                cboArrTime.SelectedIndex = 0;
                cboPeople.SelectedIndex = 0;
                cboTables.SelectedIndex = 0;
                cboRemResID.Focus();
                loadRes();

            }

        private void btnCancelRes_Click_1(object sender, EventArgs e)
        {
            //NO data to validate

            // Update data in Tables File
            //Instantiate an instance of a Table with values in form controls
            aRes.setResStatus("C");

            //Invoke The updateTable() method
            aRes.removeRes();

            //display confirmation message
            MessageBox.Show("Table is removed", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //reset UI
            cboPhone.SelectedIndex = 0;
            cboName.SelectedIndex = 0;
            grpRemResTables.Visible = false;
            cboRemResID.SelectedIndex = -1;
            cboArrTime.SelectedIndex = 0;
            cboPeople.SelectedIndex = 0;
            cboTables.SelectedIndex = 0;
            cboRemResID.Focus();
            loadRes();
        }
    }


    }

