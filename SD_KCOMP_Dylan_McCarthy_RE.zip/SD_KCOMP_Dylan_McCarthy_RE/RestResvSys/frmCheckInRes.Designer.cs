﻿
namespace RestResvSYS
{
    partial class frmCheckInRes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCheckInRes));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BTMnuCheckIn = new System.Windows.Forms.ToolStripMenuItem();
            this.exitTlStripCheckIn = new System.Windows.Forms.ToolStripMenuItem();
            this.grpCIResTables = new System.Windows.Forms.GroupBox();
            this.cboName = new System.Windows.Forms.ComboBox();
            this.cboPhone = new System.Windows.Forms.ComboBox();
            this.cboDate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboPeople = new System.Windows.Forms.ComboBox();
            this.lblAddTblSize = new System.Windows.Forms.Label();
            this.btnCIRes = new System.Windows.Forms.Button();
            this.lblCIPhoneNo = new System.Windows.Forms.Label();
            this.lblCIResName = new System.Windows.Forms.Label();
            this.cboCITables = new System.Windows.Forms.ComboBox();
            this.lblCITbl = new System.Windows.Forms.Label();
            this.lblCIArrTime = new System.Windows.Forms.Label();
            this.cboCIArrTime = new System.Windows.Forms.ComboBox();
            this.grpMakeRes = new System.Windows.Forms.GroupBox();
            this.cboCIResID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCIResID = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.grpCIResTables.SuspendLayout();
            this.grpMakeRes.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMnuCheckIn,
            this.exitTlStripCheckIn});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(939, 33);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // BTMnuCheckIn
            // 
            this.BTMnuCheckIn.Name = "BTMnuCheckIn";
            this.BTMnuCheckIn.Size = new System.Drawing.Size(180, 29);
            this.BTMnuCheckIn.Text = "Back to Main Menu";
            this.BTMnuCheckIn.Click += new System.EventHandler(this.BTMnuCheckIn_Click);
            // 
            // exitTlStripCheckIn
            // 
            this.exitTlStripCheckIn.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitTlStripCheckIn.Name = "exitTlStripCheckIn";
            this.exitTlStripCheckIn.Size = new System.Drawing.Size(55, 29);
            this.exitTlStripCheckIn.Text = "Exit";
            this.exitTlStripCheckIn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.exitTlStripCheckIn.Click += new System.EventHandler(this.exitTlStripCheckIn_Click);
            // 
            // grpCIResTables
            // 
            this.grpCIResTables.Controls.Add(this.cboName);
            this.grpCIResTables.Controls.Add(this.cboPhone);
            this.grpCIResTables.Controls.Add(this.cboDate);
            this.grpCIResTables.Controls.Add(this.label2);
            this.grpCIResTables.Controls.Add(this.cboPeople);
            this.grpCIResTables.Controls.Add(this.lblAddTblSize);
            this.grpCIResTables.Controls.Add(this.btnCIRes);
            this.grpCIResTables.Controls.Add(this.lblCIPhoneNo);
            this.grpCIResTables.Controls.Add(this.lblCIResName);
            this.grpCIResTables.Controls.Add(this.cboCITables);
            this.grpCIResTables.Controls.Add(this.lblCITbl);
            this.grpCIResTables.Controls.Add(this.lblCIArrTime);
            this.grpCIResTables.Controls.Add(this.cboCIArrTime);
            this.grpCIResTables.Location = new System.Drawing.Point(42, 232);
            this.grpCIResTables.Name = "grpCIResTables";
            this.grpCIResTables.Size = new System.Drawing.Size(866, 253);
            this.grpCIResTables.TabIndex = 26;
            this.grpCIResTables.TabStop = false;
            this.grpCIResTables.Text = "Please enter the details:";
            this.grpCIResTables.Visible = false;
            // 
            // cboName
            // 
            this.cboName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboName.FormattingEnabled = true;
            this.cboName.Location = new System.Drawing.Point(135, 37);
            this.cboName.Name = "cboName";
            this.cboName.Size = new System.Drawing.Size(103, 28);
            this.cboName.TabIndex = 36;
            // 
            // cboPhone
            // 
            this.cboPhone.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhone.FormattingEnabled = true;
            this.cboPhone.Location = new System.Drawing.Point(135, 93);
            this.cboPhone.Name = "cboPhone";
            this.cboPhone.Size = new System.Drawing.Size(103, 28);
            this.cboPhone.TabIndex = 35;
            // 
            // cboDate
            // 
            this.cboDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDate.FormattingEnabled = true;
            this.cboDate.Location = new System.Drawing.Point(437, 145);
            this.cboDate.Name = "cboDate";
            this.cboDate.Size = new System.Drawing.Size(85, 28);
            this.cboDate.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(247, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "Date Of Reservation:";
            // 
            // cboPeople
            // 
            this.cboPeople.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPeople.FormattingEnabled = true;
            this.cboPeople.Items.AddRange(new object[] {
            "2",
            "4",
            "6"});
            this.cboPeople.Location = new System.Drawing.Point(135, 146);
            this.cboPeople.Name = "cboPeople";
            this.cboPeople.Size = new System.Drawing.Size(49, 28);
            this.cboPeople.TabIndex = 30;
            // 
            // lblAddTblSize
            // 
            this.lblAddTblSize.AutoSize = true;
            this.lblAddTblSize.Location = new System.Drawing.Point(12, 148);
            this.lblAddTblSize.Name = "lblAddTblSize";
            this.lblAddTblSize.Size = new System.Drawing.Size(108, 20);
            this.lblAddTblSize.TabIndex = 29;
            this.lblAddTblSize.Text = "No. of People:";
            // 
            // btnCIRes
            // 
            this.btnCIRes.Location = new System.Drawing.Point(637, 126);
            this.btnCIRes.Name = "btnCIRes";
            this.btnCIRes.Size = new System.Drawing.Size(180, 43);
            this.btnCIRes.TabIndex = 28;
            this.btnCIRes.Text = "Check-In Reservation";
            this.btnCIRes.UseVisualStyleBackColor = true;
            this.btnCIRes.Click += new System.EventHandler(this.btnCIRes_Click);
            // 
            // lblCIPhoneNo
            // 
            this.lblCIPhoneNo.AutoSize = true;
            this.lblCIPhoneNo.Location = new System.Drawing.Point(33, 104);
            this.lblCIPhoneNo.Name = "lblCIPhoneNo";
            this.lblCIPhoneNo.Size = new System.Drawing.Size(87, 20);
            this.lblCIPhoneNo.TabIndex = 25;
            this.lblCIPhoneNo.Text = "Phone No: ";
            // 
            // lblCIResName
            // 
            this.lblCIResName.AutoSize = true;
            this.lblCIResName.Location = new System.Drawing.Point(61, 35);
            this.lblCIResName.Name = "lblCIResName";
            this.lblCIResName.Size = new System.Drawing.Size(59, 20);
            this.lblCIResName.TabIndex = 23;
            this.lblCIResName.Text = "Name: ";
            // 
            // cboCITables
            // 
            this.cboCITables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCITables.FormattingEnabled = true;
            this.cboCITables.Location = new System.Drawing.Point(437, 32);
            this.cboCITables.Name = "cboCITables";
            this.cboCITables.Size = new System.Drawing.Size(142, 28);
            this.cboCITables.TabIndex = 22;
            // 
            // lblCITbl
            // 
            this.lblCITbl.AutoSize = true;
            this.lblCITbl.Location = new System.Drawing.Point(308, 37);
            this.lblCITbl.Name = "lblCITbl";
            this.lblCITbl.Size = new System.Drawing.Size(97, 20);
            this.lblCITbl.TabIndex = 21;
            this.lblCITbl.Text = "Select Table";
            // 
            // lblCIArrTime
            // 
            this.lblCIArrTime.AutoSize = true;
            this.lblCIArrTime.Location = new System.Drawing.Point(358, 96);
            this.lblCIArrTime.Name = "lblCIArrTime";
            this.lblCIArrTime.Size = new System.Drawing.Size(47, 20);
            this.lblCIArrTime.TabIndex = 20;
            this.lblCIArrTime.Text = "Time:";
            // 
            // cboCIArrTime
            // 
            this.cboCIArrTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCIArrTime.FormattingEnabled = true;
            this.cboCIArrTime.Location = new System.Drawing.Point(437, 96);
            this.cboCIArrTime.Name = "cboCIArrTime";
            this.cboCIArrTime.Size = new System.Drawing.Size(85, 28);
            this.cboCIArrTime.TabIndex = 19;
            // 
            // grpMakeRes
            // 
            this.grpMakeRes.Controls.Add(this.cboCIResID);
            this.grpMakeRes.Controls.Add(this.label1);
            this.grpMakeRes.Controls.Add(this.lblCIResID);
            this.grpMakeRes.Location = new System.Drawing.Point(57, 50);
            this.grpMakeRes.Name = "grpMakeRes";
            this.grpMakeRes.Size = new System.Drawing.Size(516, 162);
            this.grpMakeRes.TabIndex = 27;
            this.grpMakeRes.TabStop = false;
            this.grpMakeRes.Text = "Please enter the details";
            // 
            // cboCIResID
            // 
            this.cboCIResID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCIResID.FormattingEnabled = true;
            this.cboCIResID.Location = new System.Drawing.Point(185, 43);
            this.cboCIResID.Name = "cboCIResID";
            this.cboCIResID.Size = new System.Drawing.Size(142, 28);
            this.cboCIResID.TabIndex = 23;
            this.cboCIResID.SelectedIndexChanged += new System.EventHandler(this.cboCIResID_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(327, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 12;
            // 
            // lblCIResID
            // 
            this.lblCIResID.AutoSize = true;
            this.lblCIResID.Location = new System.Drawing.Point(6, 42);
            this.lblCIResID.Name = "lblCIResID";
            this.lblCIResID.Size = new System.Drawing.Size(127, 20);
            this.lblCIResID.TabIndex = 4;
            this.lblCIResID.Text = "Reservation ID : ";
            // 
            // frmCheckInRes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 517);
            this.Controls.Add(this.grpMakeRes);
            this.Controls.Add(this.grpCIResTables);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCheckInRes";
            this.Text = "Check-In Reservation";
            this.Load += new System.EventHandler(this.frmCheckInRes_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpCIResTables.ResumeLayout(false);
            this.grpCIResTables.PerformLayout();
            this.grpMakeRes.ResumeLayout(false);
            this.grpMakeRes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BTMnuCheckIn;
        private System.Windows.Forms.ToolStripMenuItem exitTlStripCheckIn;
        private System.Windows.Forms.GroupBox grpCIResTables;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboPeople;
        private System.Windows.Forms.Label lblAddTblSize;
        private System.Windows.Forms.Button btnCIRes;
        private System.Windows.Forms.Label lblCIPhoneNo;
        private System.Windows.Forms.Label lblCIResName;
        private System.Windows.Forms.ComboBox cboCITables;
        private System.Windows.Forms.Label lblCITbl;
        private System.Windows.Forms.Label lblCIArrTime;
        private System.Windows.Forms.ComboBox cboCIArrTime;
        private System.Windows.Forms.GroupBox grpMakeRes;
        private System.Windows.Forms.ComboBox cboCIResID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCIResID;
        private System.Windows.Forms.ComboBox cboName;
        private System.Windows.Forms.ComboBox cboPhone;
        private System.Windows.Forms.ComboBox cboDate;
    }
}