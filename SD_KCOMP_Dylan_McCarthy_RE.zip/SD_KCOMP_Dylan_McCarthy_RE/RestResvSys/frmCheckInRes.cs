﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestResvSYS
{
    public partial class frmCheckInRes : Form
    {
        frmMainMenu parent;
        Reservations aRes = new Reservations();

        public frmCheckInRes()
        {
            InitializeComponent();
        }

        public frmCheckInRes(frmMainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }

        private void frmCheckInRes_Load(object sender, EventArgs e)
        {
            //loads the Reservations from the database where Status='W'
            loadRes();
        }

        private void loadRes()
        {

            //move records from ds into cboWidgets
            cboCIResID.Items.Clear();
            DataSet ds = Reservations.getSummaryRes();

            //load combo with stockNo and Description for all stock
            for (int i = 0; i < ds.Tables["SR"].Rows.Count; i++)
                cboCIResID.Items.Add(ds.Tables[0].Rows[i][0].ToString().PadLeft(3, '0') +
                " " + ds.Tables[0].Rows[i][1].ToString());

        }

        private void exitTlStripCheckIn_Click(object sender, EventArgs e)
        {
            //The System asks the user are they sure they want to exit
            var choice = MessageBox.Show("Are you sure you want to exit the system", "Exiting The System", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (choice == DialogResult.Yes)
                Application.Exit();
        }

        private void cboCIResID_SelectedIndexChanged(object sender, EventArgs e)
        {

            //loads seats and arrival times from the database in the comboboxes
            Utility.LoadPeople(cboPeople);
            Utility.ArrTime_Load(cboCIArrTime);
            Utility.cboNameLoad(cboName);
            Utility.cboTableLoad(cboCITables);
            Utility.cboPhoneLoad(cboPhone);
            Utility.cboResDate(cboDate);
            aRes.getRes(Convert.ToInt32(cboCIResID.Text.Substring(0, 3)));

            //Set cboArrTime to current value.
            cboCIArrTime.SelectedIndex = 0;
            String arrTime = aRes.getTimeRes();

            //this FOR loop finds the Arrival time that belongs to the resID selected
            for (int i = 0; !(cboCIArrTime.Text == arrTime); i++)
            {
                cboCIArrTime.SelectedIndex++;
            }

            //Set cboPeople to current value.
            cboPeople.SelectedIndex = 0;

            //this FOR loop finds the people that belongs to the resID selected
            for (int i = 0; !(Convert.ToInt32(cboPeople.Text) == aRes.getPeople()); i++)
            {
                cboPeople.SelectedIndex++;
            }

            //Sets cboName to current value
            cboName.SelectedIndex = 0;

            //this FOR loop finds the name that belongs to the resID selected
            for (int i = 0; !(cboName.Text == aRes.getName()); i++)
            {
                cboName.SelectedIndex++;
            }

            //Sets the cboPhone to the current value
            cboPhone.SelectedIndex = 0;

            //this FOR loop finds the Phone that belongs to the resID selected
            for (int i = 0; !(Convert.ToInt32(cboPhone.Text) == aRes.getPhnNo()); i++)
            {
                cboPhone.SelectedIndex++;
            }

            //Sets the cboDate to current value
            cboDate.SelectedIndex = 0;

            //this FOR loop finds the date that belongs to the resID selected
            for (int i = 0; !(cboDate.Text == aRes.getResDate()); i++)
            {
                cboDate.SelectedIndex++;
            }

            //Set cboCITables to current value
            cboCITables.SelectedIndex = 0;

            //this FOR loop finds the table number that belongs to the resID selected
            for (int i = 0; !(Convert.ToInt32(cboCITables.Text) == aRes.getTableNo()); i++)
            {
                cboCITables.SelectedIndex++;
            }

            //Setting cboCIArrTime to current value
            cboCIArrTime.SelectedIndex = 0;


            //makes the remove table visible when index changed
            grpCIResTables.Visible = true;
        }

        private void BTMnuCheckIn_Click(object sender, EventArgs e)
        {
            this.Hide();
            parent.Visible = true;
        }

        private void btnCIRes_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to check-in this Reservation ID " + cboCIResID.SelectedItem, "Check-In Reservation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (choice == DialogResult.Yes)
            {
                //NO data to validate

                // Update data in Tables File
                //Instantiate an instance of a Table with values in form controls
                aRes.setResStatus("S");

                //Invoke The CheckInRes() method
                aRes.CheckInRes();

                //display confirmation message
                MessageBox.Show("Reservation is checked-In", "Check-in Reservation!!", MessageBoxButtons.OK, MessageBoxIcon.Information);


                //reset UI
                cboPhone.SelectedIndex = 0;
                cboName.SelectedIndex = 0;
                grpCIResTables.Visible = false;
                cboDate.SelectedIndex = 0;
                cboCIResID.SelectedIndex = -1;
                cboCIArrTime.SelectedIndex = 0;
                cboPeople.SelectedIndex = 0;
                cboCITables.SelectedIndex = 0;
                cboCIResID.Focus();
                loadRes();
            }
        }
    }
}
