﻿
namespace RestResvSYS
{
    partial class frmMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainMenu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ToolStripManageTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripAddTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripUpdateTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuRemTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripRes = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMakeRes = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripCancelRes = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripCheckIn = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripPayBill = new System.Windows.Forms.ToolStripMenuItem();
            this.performAdminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripAnnTotalRev = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripTblResChart = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMainMnu = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripManageTbl,
            this.ToolStripRes,
            this.performAdminToolStripMenuItem,
            this.exitMainMnu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(870, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ToolStripManageTbl
            // 
            this.ToolStripManageTbl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripAddTbl,
            this.ToolStripUpdateTbl,
            this.MnuRemTbl});
            this.ToolStripManageTbl.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToolStripManageTbl.Name = "ToolStripManageTbl";
            this.ToolStripManageTbl.Size = new System.Drawing.Size(150, 29);
            this.ToolStripManageTbl.Text = "Manage Tables";
            // 
            // ToolStripAddTbl
            // 
            this.ToolStripAddTbl.Name = "ToolStripAddTbl";
            this.ToolStripAddTbl.Size = new System.Drawing.Size(226, 34);
            this.ToolStripAddTbl.Text = "Add Table";
            this.ToolStripAddTbl.Click += new System.EventHandler(this.ToolStripAddTbl_Click);
            // 
            // ToolStripUpdateTbl
            // 
            this.ToolStripUpdateTbl.Name = "ToolStripUpdateTbl";
            this.ToolStripUpdateTbl.Size = new System.Drawing.Size(226, 34);
            this.ToolStripUpdateTbl.Text = "Update Table";
            this.ToolStripUpdateTbl.Click += new System.EventHandler(this.ToolStripUpdateTbl_Click);
            // 
            // MnuRemTbl
            // 
            this.MnuRemTbl.Name = "MnuRemTbl";
            this.MnuRemTbl.Size = new System.Drawing.Size(226, 34);
            this.MnuRemTbl.Text = "Remove Table";
            this.MnuRemTbl.Click += new System.EventHandler(this.MnuRemTbl_Click);
            // 
            // ToolStripRes
            // 
            this.ToolStripRes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMakeRes,
            this.ToolStripCancelRes,
            this.ToolStripCheckIn,
            this.ToolStripPayBill});
            this.ToolStripRes.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToolStripRes.Name = "ToolStripRes";
            this.ToolStripRes.Size = new System.Drawing.Size(199, 29);
            this.ToolStripRes.Text = "Process Reservations";
            // 
            // ToolStripMakeRes
            // 
            this.ToolStripMakeRes.Name = "ToolStripMakeRes";
            this.ToolStripMakeRes.Size = new System.Drawing.Size(268, 34);
            this.ToolStripMakeRes.Text = "Make Reservation";
            this.ToolStripMakeRes.Click += new System.EventHandler(this.ToolStripMakeRes_Click);
            // 
            // ToolStripCancelRes
            // 
            this.ToolStripCancelRes.Name = "ToolStripCancelRes";
            this.ToolStripCancelRes.Size = new System.Drawing.Size(268, 34);
            this.ToolStripCancelRes.Text = "Cancel Reservation";
            this.ToolStripCancelRes.Click += new System.EventHandler(this.ToolStripCancelRes_Click);
            // 
            // ToolStripCheckIn
            // 
            this.ToolStripCheckIn.Name = "ToolStripCheckIn";
            this.ToolStripCheckIn.Size = new System.Drawing.Size(268, 34);
            this.ToolStripCheckIn.Text = "Check-In";
            this.ToolStripCheckIn.Click += new System.EventHandler(this.ToolStripCheckIn_Click);
            // 
            // ToolStripPayBill
            // 
            this.ToolStripPayBill.Name = "ToolStripPayBill";
            this.ToolStripPayBill.Size = new System.Drawing.Size(268, 34);
            this.ToolStripPayBill.Text = "Pay Bill";
            this.ToolStripPayBill.Click += new System.EventHandler(this.ToolStripPayBill_Click);
            // 
            // performAdminToolStripMenuItem
            // 
            this.performAdminToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripAnnTotalRev,
            this.ToolStripTblResChart});
            this.performAdminToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.performAdminToolStripMenuItem.Name = "performAdminToolStripMenuItem";
            this.performAdminToolStripMenuItem.Size = new System.Drawing.Size(153, 29);
            this.performAdminToolStripMenuItem.Text = "Perform Admin";
            // 
            // ToolStripAnnTotalRev
            // 
            this.ToolStripAnnTotalRev.Name = "ToolStripAnnTotalRev";
            this.ToolStripAnnTotalRev.Size = new System.Drawing.Size(308, 34);
            this.ToolStripAnnTotalRev.Text = "Annual Total Revenue";
            this.ToolStripAnnTotalRev.Click += new System.EventHandler(this.ToolStripAnnTotalRev_Click);
            // 
            // ToolStripTblResChart
            // 
            this.ToolStripTblResChart.Name = "ToolStripTblResChart";
            this.ToolStripTblResChart.Size = new System.Drawing.Size(308, 34);
            this.ToolStripTblResChart.Text = "Table Reservation Chart";
            this.ToolStripTblResChart.Click += new System.EventHandler(this.ToolStripTblResChart_Click);
            // 
            // exitMainMnu
            // 
            this.exitMainMnu.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitMainMnu.Name = "exitMainMnu";
            this.exitMainMnu.Size = new System.Drawing.Size(55, 29);
            this.exitMainMnu.Text = "Exit";
            this.exitMainMnu.Click += new System.EventHandler(this.exitMainMnu_Click);
            // 
            // frmMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(870, 542);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMainMenu";
            this.Text = " ";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripManageTbl;
        private System.Windows.Forms.ToolStripMenuItem ToolStripAddTbl;
        private System.Windows.Forms.ToolStripMenuItem ToolStripUpdateTbl;
        private System.Windows.Forms.ToolStripMenuItem MnuRemTbl;
        private System.Windows.Forms.ToolStripMenuItem ToolStripRes;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMakeRes;
        private System.Windows.Forms.ToolStripMenuItem ToolStripCancelRes;
        private System.Windows.Forms.ToolStripMenuItem ToolStripCheckIn;
        private System.Windows.Forms.ToolStripMenuItem ToolStripPayBill;
        private System.Windows.Forms.ToolStripMenuItem performAdminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripAnnTotalRev;
        private System.Windows.Forms.ToolStripMenuItem ToolStripTblResChart;
        private System.Windows.Forms.ToolStripMenuItem exitMainMnu;
    }
}

