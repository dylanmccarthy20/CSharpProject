﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestResvSYS
{
    public partial class frmMainMenu : Form
    {
        public frmMainMenu()
        {
            InitializeComponent();
        }

        private void ToolStripTblResChart_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmYearlyTableCht tblResChart = new frmYearlyTableCht(this);
            tblResChart.Show();
        }

        private void ToolStripAddTbl_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmAddTable tbl = new frmAddTable(this);
            tbl.Show();
        }

        private void exitMainMnu_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to exit the system", "Exiting The System", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (choice == DialogResult.Yes)
                Application.Exit();
        }     

        private void ToolStripUpdateTbl_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmUpdateTable updateTable = new frmUpdateTable(this);
            updateTable.Show();

        }

  

        private void ToolStripMakeRes_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMakeRes makeRes = new frmMakeRes(this);
            makeRes.Show();

        }

        private void ToolStripCancelRes_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmCancelRes cancelRes = new frmCancelRes(this);
            cancelRes.Show();
        }



        private void ToolStripCheckIn_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmCheckInRes checkInRes = new frmCheckInRes(this);
            checkInRes.Show();
        }

        private void ToolStripPayBill_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmPayBillRes payBillRes = new frmPayBillRes(this);
            payBillRes.Show();
        }

   

        private void ToolStripAnnTotalRev_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmYearlyRevenue annTtlRev = new frmYearlyRevenue(this);
            annTtlRev.Show();

        }



        private void frmMainMenu_Load(object sender, EventArgs e)
        {
             
        }

        private void MnuRemTbl_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmRemoveTable removeTable = new frmRemoveTable(this);
            removeTable.Show();
        }

        private void MnuRemTbl_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frmRemoveTable removeTable = new frmRemoveTable(this);
            removeTable.Show();
        }
    }
}
