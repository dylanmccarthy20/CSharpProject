﻿
namespace RestResvSYS
{
    partial class frmMakeRes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMakeRes));
            this.txtResID = new System.Windows.Forms.TextBox();
            this.lblMakeRes = new System.Windows.Forms.Label();
            this.grpMakeRes = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCheck = new System.Windows.Forms.Button();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.cboPeople = new System.Windows.Forms.ComboBox();
            this.lblAddTblSize = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exitTlMakeRes = new System.Windows.Forms.ToolStripMenuItem();
            this.BTMMakeRes = new System.Windows.Forms.ToolStripMenuItem();
            this.grpTables = new System.Windows.Forms.GroupBox();
            this.btnMakeRes = new System.Windows.Forms.Button();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblPhoneNo = new System.Windows.Forms.Label();
            this.lblResName = new System.Windows.Forms.Label();
            this.cboTables = new System.Windows.Forms.ComboBox();
            this.lblAddTblLocation = new System.Windows.Forms.Label();
            this.lblArrTime = new System.Windows.Forms.Label();
            this.cboArrTime = new System.Windows.Forms.ComboBox();
            this.grpMakeRes.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.grpTables.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtResID
            // 
            this.txtResID.Enabled = false;
            this.txtResID.Location = new System.Drawing.Point(193, 45);
            this.txtResID.MaxLength = 2;
            this.txtResID.Name = "txtResID";
            this.txtResID.ReadOnly = true;
            this.txtResID.Size = new System.Drawing.Size(95, 26);
            this.txtResID.TabIndex = 0;
            // 
            // lblMakeRes
            // 
            this.lblMakeRes.AutoSize = true;
            this.lblMakeRes.Location = new System.Drawing.Point(24, 45);
            this.lblMakeRes.Name = "lblMakeRes";
            this.lblMakeRes.Size = new System.Drawing.Size(127, 20);
            this.lblMakeRes.TabIndex = 4;
            this.lblMakeRes.Text = "Reservation ID : ";
            // 
            // grpMakeRes
            // 
            this.grpMakeRes.Controls.Add(this.label2);
            this.grpMakeRes.Controls.Add(this.btnCheck);
            this.grpMakeRes.Controls.Add(this.dtpDate);
            this.grpMakeRes.Controls.Add(this.label1);
            this.grpMakeRes.Controls.Add(this.cboPeople);
            this.grpMakeRes.Controls.Add(this.lblAddTblSize);
            this.grpMakeRes.Controls.Add(this.lblMakeRes);
            this.grpMakeRes.Controls.Add(this.txtResID);
            this.grpMakeRes.Location = new System.Drawing.Point(12, 55);
            this.grpMakeRes.Name = "grpMakeRes";
            this.grpMakeRes.Size = new System.Drawing.Size(700, 261);
            this.grpMakeRes.TabIndex = 6;
            this.grpMakeRes.TabStop = false;
            this.grpMakeRes.Text = "Please enter the details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 20);
            this.label2.TabIndex = 17;
            this.label2.Text = "Date Of Reservation: ";
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(193, 194);
            this.btnCheck.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(164, 35);
            this.btnCheck.TabIndex = 16;
            this.btnCheck.Text = "Check Availability";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // dtpDate
            // 
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDate.Location = new System.Drawing.Point(193, 75);
            this.dtpDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dtpDate.MinDate = new System.DateTime(2021, 4, 26, 0, 0, 0, 0);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(298, 26);
            this.dtpDate.TabIndex = 15;
            this.dtpDate.Value = new System.DateTime(2021, 5, 8, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(327, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 12;
            // 
            // cboPeople
            // 
            this.cboPeople.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPeople.FormattingEnabled = true;
            this.cboPeople.Location = new System.Drawing.Point(193, 139);
            this.cboPeople.Name = "cboPeople";
            this.cboPeople.Size = new System.Drawing.Size(72, 28);
            this.cboPeople.TabIndex = 7;
            // 
            // lblAddTblSize
            // 
            this.lblAddTblSize.AutoSize = true;
            this.lblAddTblSize.Location = new System.Drawing.Point(15, 139);
            this.lblAddTblSize.Name = "lblAddTblSize";
            this.lblAddTblSize.Size = new System.Drawing.Size(136, 20);
            this.lblAddTblSize.TabIndex = 5;
            this.lblAddTblSize.Text = "Number of People";
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitTlMakeRes,
            this.BTMMakeRes});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1200, 33);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exitTlMakeRes
            // 
            this.exitTlMakeRes.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitTlMakeRes.Name = "exitTlMakeRes";
            this.exitTlMakeRes.Size = new System.Drawing.Size(55, 29);
            this.exitTlMakeRes.Text = "Exit";
            this.exitTlMakeRes.Click += new System.EventHandler(this.exitTlMakeRes_Click);
            // 
            // BTMMakeRes
            // 
            this.BTMMakeRes.DoubleClickEnabled = true;
            this.BTMMakeRes.Name = "BTMMakeRes";
            this.BTMMakeRes.Size = new System.Drawing.Size(180, 29);
            this.BTMMakeRes.Text = "Back to Main Menu";
            this.BTMMakeRes.Click += new System.EventHandler(this.BTMMakeRes_Click);
            // 
            // grpTables
            // 
            this.grpTables.Controls.Add(this.btnMakeRes);
            this.grpTables.Controls.Add(this.txtPhoneNo);
            this.grpTables.Controls.Add(this.txtName);
            this.grpTables.Controls.Add(this.lblPhoneNo);
            this.grpTables.Controls.Add(this.lblResName);
            this.grpTables.Controls.Add(this.cboTables);
            this.grpTables.Controls.Add(this.lblAddTblLocation);
            this.grpTables.Controls.Add(this.lblArrTime);
            this.grpTables.Controls.Add(this.cboArrTime);
            this.grpTables.Location = new System.Drawing.Point(12, 362);
            this.grpTables.Name = "grpTables";
            this.grpTables.Size = new System.Drawing.Size(1090, 171);
            this.grpTables.TabIndex = 19;
            this.grpTables.TabStop = false;
            this.grpTables.Text = "Please enter the details:";
            this.grpTables.Visible = false;
            this.grpTables.VisibleChanged += new System.EventHandler(this.btnCheck_Click);
            // 
            // btnMakeRes
            // 
            this.btnMakeRes.Location = new System.Drawing.Point(727, 86);
            this.btnMakeRes.Name = "btnMakeRes";
            this.btnMakeRes.Size = new System.Drawing.Size(155, 38);
            this.btnMakeRes.TabIndex = 28;
            this.btnMakeRes.Text = "Make Reservation";
            this.btnMakeRes.UseVisualStyleBackColor = true;
            this.btnMakeRes.Click += new System.EventHandler(this.btnMakeRes_Click);
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.Location = new System.Drawing.Point(515, 39);
            this.txtPhoneNo.MaxLength = 10;
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(141, 26);
            this.txtPhoneNo.TabIndex = 27;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(515, 104);
            this.txtName.MaxLength = 20;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(141, 26);
            this.txtName.TabIndex = 26;
            // 
            // lblPhoneNo
            // 
            this.lblPhoneNo.AutoSize = true;
            this.lblPhoneNo.Location = new System.Drawing.Point(386, 45);
            this.lblPhoneNo.Name = "lblPhoneNo";
            this.lblPhoneNo.Size = new System.Drawing.Size(123, 20);
            this.lblPhoneNo.TabIndex = 25;
            this.lblPhoneNo.Text = "Phone Number: ";
            // 
            // lblResName
            // 
            this.lblResName.AutoSize = true;
            this.lblResName.Location = new System.Drawing.Point(386, 104);
            this.lblResName.Name = "lblResName";
            this.lblResName.Size = new System.Drawing.Size(59, 20);
            this.lblResName.TabIndex = 23;
            this.lblResName.Text = "Name: ";
            // 
            // cboTables
            // 
            this.cboTables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTables.FormattingEnabled = true;
            this.cboTables.Location = new System.Drawing.Point(146, 37);
            this.cboTables.Name = "cboTables";
            this.cboTables.Size = new System.Drawing.Size(142, 28);
            this.cboTables.TabIndex = 22;
            // 
            // lblAddTblLocation
            // 
            this.lblAddTblLocation.AutoSize = true;
            this.lblAddTblLocation.Location = new System.Drawing.Point(15, 40);
            this.lblAddTblLocation.Name = "lblAddTblLocation";
            this.lblAddTblLocation.Size = new System.Drawing.Size(97, 20);
            this.lblAddTblLocation.TabIndex = 21;
            this.lblAddTblLocation.Text = "Select Table";
            // 
            // lblArrTime
            // 
            this.lblArrTime.AutoSize = true;
            this.lblArrTime.Location = new System.Drawing.Point(65, 104);
            this.lblArrTime.Name = "lblArrTime";
            this.lblArrTime.Size = new System.Drawing.Size(47, 20);
            this.lblArrTime.TabIndex = 20;
            this.lblArrTime.Text = "Time:";
            // 
            // cboArrTime
            // 
            this.cboArrTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboArrTime.FormattingEnabled = true;
            this.cboArrTime.Location = new System.Drawing.Point(146, 101);
            this.cboArrTime.Name = "cboArrTime";
            this.cboArrTime.Size = new System.Drawing.Size(142, 28);
            this.cboArrTime.TabIndex = 19;
            // 
            // frmMakeRes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 553);
            this.Controls.Add(this.grpTables);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.grpMakeRes);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMakeRes";
            this.Text = "Make Reservations";
            this.Load += new System.EventHandler(this.frmMakeRes_Load);
            this.grpMakeRes.ResumeLayout(false);
            this.grpMakeRes.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpTables.ResumeLayout(false);
            this.grpTables.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtResID;
        private System.Windows.Forms.Label lblMakeRes;
        private System.Windows.Forms.GroupBox grpMakeRes;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exitTlMakeRes;
        private System.Windows.Forms.ToolStripMenuItem BTMMakeRes;
        private System.Windows.Forms.GroupBox grpTables;
        private System.Windows.Forms.ComboBox cboTables;
        private System.Windows.Forms.Label lblAddTblLocation;
        private System.Windows.Forms.Label lblArrTime;
        private System.Windows.Forms.ComboBox cboArrTime;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Label lblPhoneNo;
        private System.Windows.Forms.Label lblResName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.Button btnMakeRes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboPeople;
        private System.Windows.Forms.Label lblAddTblSize;
    }
}