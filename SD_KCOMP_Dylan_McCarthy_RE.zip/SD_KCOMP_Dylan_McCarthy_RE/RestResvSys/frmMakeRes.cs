﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestResvSYS
{
    public partial class frmMakeRes : Form
    {
        frmMainMenu parent;
        Reservations aRes = new Reservations();
        Utility aUtility = new Utility();
        Tables aTables = new Tables();
        public frmMakeRes()
        {
            InitializeComponent();
        }
        public frmMakeRes(frmMainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }


        private void frmMakeRes_Load(object sender, EventArgs e)
        {
            //loads the People Combobox
            Utility.LoadPeople(cboPeople);

           //get next Reservation ID
           txtResID.Text = Reservations.getNextResID().ToString("00000");
            
           grpTables.Visible = false;
        }


        private void exitTlMakeRes_Click(object sender, EventArgs e)
        {
            var choice =MessageBox.Show("Are you sure you want to exit:", "Exit??", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (choice == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            
            if (cboPeople.SelectedIndex == -1)
            {
                var choice = MessageBox.Show("Number of people wasn't entered","Invalid number of people!!",MessageBoxButtons.OK,MessageBoxIcon.Error);
                grpTables.Visible = false;
            }

            DataSet ds=Reservations.getAvailableTables(String.Format("{0:dd-MMM-yy}",dtpDate.Value), Convert.ToInt32(cboPeople.Text));


            cboArrTime.Items.Clear();
            cboTables.Items.Clear();

            for (int i=0;i< ds.Tables[0].Rows.Count;i++)
            {
               //cboTables.Items.Add(ds.Tables[0].Rows[i][0]);

                cboTables.Items.Add(String.Format("{0:000}",(ds.Tables[0].Rows[i][0])));
            }
            
            //load Arrival Times from database to comboboxes
            Utility.ArrTime_Load(cboArrTime);

            grpTables.Visible = true;
                        
        }

        private void btnMakeRes_Click(object sender, EventArgs e)
        {
            if (txtName == null)
            {
                var choice = MessageBox.Show("The name you entered was invalid!!", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } 
            else if (txtPhoneNo == null)
            {
                var choice = MessageBox.Show("The phone number you entered was invalid!!", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
            
           Reservations aRes = new Reservations(Convert.ToInt32(txtResID.Text),txtName.Text,Convert.ToInt32(cboTables.Text),
                Convert.ToInt32(txtPhoneNo.Text), String.Format("{0:dd-MMM-yy}", dtpDate.Value), Convert.ToString(cboArrTime.Text),Convert.ToInt32(cboPeople.Text),
                0,"W");

            aRes.makeRes();

            MessageBox.Show("The Reservation details you entered is added!", "Reservation Made!!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtResID.Text = Reservations.getNextResID().ToString("00000");
            txtPhoneNo.Clear();
            grpTables.Visible = false;
            txtName.Clear();
            dtpDate=null;
            txtPhoneNo.Clear();
            cboPeople.SelectedIndex = -1;
            cboTables.SelectedIndex= -1;
            cboArrTime.SelectedIndex = -1;
        }

        private void BTMMakeRes_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }
    }
   
}
