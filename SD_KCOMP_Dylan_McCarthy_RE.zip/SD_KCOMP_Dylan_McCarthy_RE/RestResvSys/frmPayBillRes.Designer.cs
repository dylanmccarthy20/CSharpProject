﻿
namespace RestResvSYS
{
    partial class frmPayBillRes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPayBillRes));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BTMnuPayBill = new System.Windows.Forms.ToolStripMenuItem();
            this.exitTlStrpPayBill = new System.Windows.Forms.ToolStripMenuItem();
            this.grpMakeRes = new System.Windows.Forms.GroupBox();
            this.cboPBResID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPBResID = new System.Windows.Forms.Label();
            this.grpPBResTables = new System.Windows.Forms.GroupBox();
            this.txtBillAmt = new System.Windows.Forms.TextBox();
            this.cboDate = new System.Windows.Forms.ComboBox();
            this.cboPhone = new System.Windows.Forms.ComboBox();
            this.cboName = new System.Windows.Forms.ComboBox();
            this.lblBillAmt = new System.Windows.Forms.Label();
            this.lblPBDate = new System.Windows.Forms.Label();
            this.cboPBPeople = new System.Windows.Forms.ComboBox();
            this.lblPBppl = new System.Windows.Forms.Label();
            this.btnPBRes = new System.Windows.Forms.Button();
            this.lblPBPhoneNo = new System.Windows.Forms.Label();
            this.lblPBResName = new System.Windows.Forms.Label();
            this.cboPBTables = new System.Windows.Forms.ComboBox();
            this.lblPBTbl = new System.Windows.Forms.Label();
            this.lblPBArrTime = new System.Windows.Forms.Label();
            this.cboPBArrTime = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.grpMakeRes.SuspendLayout();
            this.grpPBResTables.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMnuPayBill,
            this.exitTlStrpPayBill});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // BTMnuPayBill
            // 
            this.BTMnuPayBill.Name = "BTMnuPayBill";
            this.BTMnuPayBill.Size = new System.Drawing.Size(180, 29);
            this.BTMnuPayBill.Text = "Back to Main Menu";
            this.BTMnuPayBill.Click += new System.EventHandler(this.BTMnuPayBill_Click);
            // 
            // exitTlStrpPayBill
            // 
            this.exitTlStrpPayBill.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitTlStrpPayBill.Name = "exitTlStrpPayBill";
            this.exitTlStrpPayBill.Size = new System.Drawing.Size(55, 29);
            this.exitTlStrpPayBill.Text = "Exit";
            this.exitTlStrpPayBill.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.exitTlStrpPayBill.Click += new System.EventHandler(this.exitTlStrpPayBill_Click);
            // 
            // grpMakeRes
            // 
            this.grpMakeRes.Controls.Add(this.cboPBResID);
            this.grpMakeRes.Controls.Add(this.label1);
            this.grpMakeRes.Controls.Add(this.lblPBResID);
            this.grpMakeRes.Location = new System.Drawing.Point(32, 51);
            this.grpMakeRes.Name = "grpMakeRes";
            this.grpMakeRes.Size = new System.Drawing.Size(489, 133);
            this.grpMakeRes.TabIndex = 29;
            this.grpMakeRes.TabStop = false;
            this.grpMakeRes.Text = "Please enter the details";
            // 
            // cboPBResID
            // 
            this.cboPBResID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPBResID.FormattingEnabled = true;
            this.cboPBResID.Location = new System.Drawing.Point(185, 43);
            this.cboPBResID.Name = "cboPBResID";
            this.cboPBResID.Size = new System.Drawing.Size(142, 28);
            this.cboPBResID.TabIndex = 23;
            this.cboPBResID.SelectedIndexChanged += new System.EventHandler(this.cboPBResID_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(327, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 12;
            // 
            // lblPBResID
            // 
            this.lblPBResID.AutoSize = true;
            this.lblPBResID.Location = new System.Drawing.Point(6, 42);
            this.lblPBResID.Name = "lblPBResID";
            this.lblPBResID.Size = new System.Drawing.Size(127, 20);
            this.lblPBResID.TabIndex = 4;
            this.lblPBResID.Text = "Reservation ID : ";
            // 
            // grpPBResTables
            // 
            this.grpPBResTables.Controls.Add(this.txtBillAmt);
            this.grpPBResTables.Controls.Add(this.cboDate);
            this.grpPBResTables.Controls.Add(this.cboPhone);
            this.grpPBResTables.Controls.Add(this.cboName);
            this.grpPBResTables.Controls.Add(this.lblBillAmt);
            this.grpPBResTables.Controls.Add(this.lblPBDate);
            this.grpPBResTables.Controls.Add(this.cboPBPeople);
            this.grpPBResTables.Controls.Add(this.lblPBppl);
            this.grpPBResTables.Controls.Add(this.btnPBRes);
            this.grpPBResTables.Controls.Add(this.lblPBPhoneNo);
            this.grpPBResTables.Controls.Add(this.lblPBResName);
            this.grpPBResTables.Controls.Add(this.cboPBTables);
            this.grpPBResTables.Controls.Add(this.lblPBTbl);
            this.grpPBResTables.Controls.Add(this.lblPBArrTime);
            this.grpPBResTables.Controls.Add(this.cboPBArrTime);
            this.grpPBResTables.Location = new System.Drawing.Point(32, 201);
            this.grpPBResTables.Name = "grpPBResTables";
            this.grpPBResTables.Size = new System.Drawing.Size(756, 193);
            this.grpPBResTables.TabIndex = 28;
            this.grpPBResTables.TabStop = false;
            this.grpPBResTables.Text = "Please enter the details:";
            this.grpPBResTables.Visible = false;
            // 
            // txtBillAmt
            // 
            this.txtBillAmt.Location = new System.Drawing.Point(605, 29);
            this.txtBillAmt.Name = "txtBillAmt";
            this.txtBillAmt.Size = new System.Drawing.Size(100, 26);
            this.txtBillAmt.TabIndex = 39;
            // 
            // cboDate
            // 
            this.cboDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDate.FormattingEnabled = true;
            this.cboDate.Location = new System.Drawing.Point(333, 145);
            this.cboDate.Name = "cboDate";
            this.cboDate.Size = new System.Drawing.Size(113, 28);
            this.cboDate.TabIndex = 38;
            // 
            // cboPhone
            // 
            this.cboPhone.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhone.FormattingEnabled = true;
            this.cboPhone.Location = new System.Drawing.Point(135, 101);
            this.cboPhone.Name = "cboPhone";
            this.cboPhone.Size = new System.Drawing.Size(104, 28);
            this.cboPhone.TabIndex = 37;
            // 
            // cboName
            // 
            this.cboName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboName.FormattingEnabled = true;
            this.cboName.Location = new System.Drawing.Point(135, 32);
            this.cboName.Name = "cboName";
            this.cboName.Size = new System.Drawing.Size(104, 28);
            this.cboName.TabIndex = 36;
            // 
            // lblBillAmt
            // 
            this.lblBillAmt.AutoSize = true;
            this.lblBillAmt.Location = new System.Drawing.Point(506, 32);
            this.lblBillAmt.Name = "lblBillAmt";
            this.lblBillAmt.Size = new System.Drawing.Size(93, 20);
            this.lblBillAmt.TabIndex = 35;
            this.lblBillAmt.Text = "Bill Amount:";
            // 
            // lblPBDate
            // 
            this.lblPBDate.AutoSize = true;
            this.lblPBDate.Location = new System.Drawing.Point(279, 148);
            this.lblPBDate.Name = "lblPBDate";
            this.lblPBDate.Size = new System.Drawing.Size(48, 20);
            this.lblPBDate.TabIndex = 32;
            this.lblPBDate.Text = "Date:";
            // 
            // cboPBPeople
            // 
            this.cboPBPeople.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPBPeople.FormattingEnabled = true;
            this.cboPBPeople.Items.AddRange(new object[] {
            "2",
            "4",
            "6"});
            this.cboPBPeople.Location = new System.Drawing.Point(135, 146);
            this.cboPBPeople.Name = "cboPBPeople";
            this.cboPBPeople.Size = new System.Drawing.Size(49, 28);
            this.cboPBPeople.TabIndex = 30;
            // 
            // lblPBppl
            // 
            this.lblPBppl.AutoSize = true;
            this.lblPBppl.Location = new System.Drawing.Point(12, 148);
            this.lblPBppl.Name = "lblPBppl";
            this.lblPBppl.Size = new System.Drawing.Size(108, 20);
            this.lblPBppl.TabIndex = 29;
            this.lblPBppl.Text = "No. of People:";
            // 
            // btnPBRes
            // 
            this.btnPBRes.Location = new System.Drawing.Point(584, 131);
            this.btnPBRes.Name = "btnPBRes";
            this.btnPBRes.Size = new System.Drawing.Size(136, 43);
            this.btnPBRes.TabIndex = 28;
            this.btnPBRes.Text = "Pay Bill";
            this.btnPBRes.UseVisualStyleBackColor = true;
            this.btnPBRes.Click += new System.EventHandler(this.btnPBRes_Click);
            // 
            // lblPBPhoneNo
            // 
            this.lblPBPhoneNo.AutoSize = true;
            this.lblPBPhoneNo.Location = new System.Drawing.Point(33, 104);
            this.lblPBPhoneNo.Name = "lblPBPhoneNo";
            this.lblPBPhoneNo.Size = new System.Drawing.Size(87, 20);
            this.lblPBPhoneNo.TabIndex = 25;
            this.lblPBPhoneNo.Text = "Phone No: ";
            // 
            // lblPBResName
            // 
            this.lblPBResName.AutoSize = true;
            this.lblPBResName.Location = new System.Drawing.Point(61, 35);
            this.lblPBResName.Name = "lblPBResName";
            this.lblPBResName.Size = new System.Drawing.Size(59, 20);
            this.lblPBResName.TabIndex = 23;
            this.lblPBResName.Text = "Name: ";
            // 
            // cboPBTables
            // 
            this.cboPBTables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPBTables.FormattingEnabled = true;
            this.cboPBTables.Location = new System.Drawing.Point(377, 30);
            this.cboPBTables.Name = "cboPBTables";
            this.cboPBTables.Size = new System.Drawing.Size(69, 28);
            this.cboPBTables.TabIndex = 22;
            // 
            // lblPBTbl
            // 
            this.lblPBTbl.AutoSize = true;
            this.lblPBTbl.Location = new System.Drawing.Point(269, 34);
            this.lblPBTbl.Name = "lblPBTbl";
            this.lblPBTbl.Size = new System.Drawing.Size(101, 20);
            this.lblPBTbl.TabIndex = 21;
            this.lblPBTbl.Text = "Select Table:";
            // 
            // lblPBArrTime
            // 
            this.lblPBArrTime.AutoSize = true;
            this.lblPBArrTime.Location = new System.Drawing.Point(280, 98);
            this.lblPBArrTime.Name = "lblPBArrTime";
            this.lblPBArrTime.Size = new System.Drawing.Size(47, 20);
            this.lblPBArrTime.TabIndex = 20;
            this.lblPBArrTime.Text = "Time:";
            // 
            // cboPBArrTime
            // 
            this.cboPBArrTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPBArrTime.FormattingEnabled = true;
            this.cboPBArrTime.Location = new System.Drawing.Point(333, 95);
            this.cboPBArrTime.Name = "cboPBArrTime";
            this.cboPBArrTime.Size = new System.Drawing.Size(113, 28);
            this.cboPBArrTime.TabIndex = 19;
            // 
            // frmPayBillRes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grpMakeRes);
            this.Controls.Add(this.grpPBResTables);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmPayBillRes";
            this.Text = "Pay Bill";
            this.Load += new System.EventHandler(this.frmPayBillRes_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpMakeRes.ResumeLayout(false);
            this.grpMakeRes.PerformLayout();
            this.grpPBResTables.ResumeLayout(false);
            this.grpPBResTables.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BTMnuPayBill;
        private System.Windows.Forms.ToolStripMenuItem exitTlStrpPayBill;
        private System.Windows.Forms.GroupBox grpMakeRes;
        private System.Windows.Forms.ComboBox cboPBResID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPBResID;
        private System.Windows.Forms.GroupBox grpPBResTables;
        private System.Windows.Forms.Label lblPBDate;
        private System.Windows.Forms.ComboBox cboPBPeople;
        private System.Windows.Forms.Label lblPBppl;
        private System.Windows.Forms.Button btnPBRes;
        private System.Windows.Forms.Label lblPBPhoneNo;
        private System.Windows.Forms.Label lblPBResName;
        private System.Windows.Forms.ComboBox cboPBTables;
        private System.Windows.Forms.Label lblPBTbl;
        private System.Windows.Forms.Label lblPBArrTime;
        private System.Windows.Forms.ComboBox cboPBArrTime;
        private System.Windows.Forms.Label lblBillAmt;
        private System.Windows.Forms.ComboBox cboPhone;
        private System.Windows.Forms.ComboBox cboName;
        private System.Windows.Forms.ComboBox cboDate;
        private System.Windows.Forms.TextBox txtBillAmt;
    }
}