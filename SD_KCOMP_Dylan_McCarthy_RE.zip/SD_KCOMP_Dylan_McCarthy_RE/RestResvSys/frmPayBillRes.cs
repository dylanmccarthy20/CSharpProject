﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestResvSYS
{
    public partial class frmPayBillRes : Form
    {
        frmMainMenu parent;
        Reservations aRes = new Reservations();
        public frmPayBillRes()
        {
            InitializeComponent();
        }
        public frmPayBillRes(frmMainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }

        private void exitTlStrpPayBill_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to exit the system", "Exiting The System", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (choice == DialogResult.Yes)
                Application.Exit();
        }
        private void cboPBResID_SelectedIndexChanged(object sender, EventArgs e)
        {

            //loads seats and arrival times from the database in the comboboxes
            Utility.LoadPeople(cboPBPeople);
            Utility.ArrTime_Load(cboPBArrTime);
            Utility.cboNameLoad(cboName);
            Utility.cboResDate(cboDate);
            Utility.cboTableLoad(cboPBTables);
            Utility.cboPhoneLoad(cboPhone);

            aRes.getRes(Convert.ToInt32(cboPBResID.Text.Substring(0, 3)));


            //Set cboArrTime to current value.
            cboPBArrTime.SelectedIndex = 0;

            String arrTime = aRes.getTimeRes();

            //this FOR loop finds the Arrival time that belongs to the resID selected
            for (int i = 0; !(cboPBArrTime.Text == arrTime); i++)
            {
                cboPBArrTime.SelectedIndex++;
            }

            //Set cboPeople to current value.
            cboPhone.SelectedIndex=0;

            //this FOR loop finds the phone number that belongs to the resID selected
            for (int i = 0; !(Convert.ToInt32(cboPhone.Text) == aRes.getPhnNo()); i++)
            {
                cboPhone.SelectedIndex++;
            }

            //Set cboPeople to current value.
            cboPBPeople.SelectedIndex = 0;

            //this FOR loop finds the people that belongs to the resID selected
            for (int i = 0; !(Convert.ToInt32(cboPBPeople.Text) == aRes.getPeople()); i++)
            {
                cboPBPeople.SelectedIndex++;
            }

            cboPBTables.SelectedIndex = 0;

            for (int i = 0; !(Convert.ToInt32(cboPBTables.Text) == aRes.getTableNo()); i++)
            {
                cboPBTables.SelectedIndex++;
            }

            //Set cboName to current value.
            cboName.SelectedIndex = 0;

            //this FOR loop finds the name that belongs to the resID selected
            for (int i = 0; !(cboName.Text == aRes.getName()); i++)
            {
                cboName.SelectedIndex++;
            }

            //Set cboDate to current value.
            cboDate.SelectedIndex = 0;

            //this FOR loop finds the phone number that belongs to the resID selected
            for (int i = 0; !(cboDate.Text == aRes.getResDate()); i++)
            {
                cboDate.SelectedIndex++;

            }
            //Setting cboTime to current value

            cboPBArrTime.SelectedIndex = 0;


            //makes the remove table visible when index changed
            grpPBResTables.Visible = true;

            aRes.getRes(Convert.ToInt32(cboPBResID.Text.Substring(0, 3)));
        }

        private void frmPayBillRes_Load(object sender, EventArgs e)
        {
            loadRes();
        }

        private void loadRes()
        {

            //move records from ds into cboWidgets
            cboPBResID.Items.Clear();
            DataSet ds = Reservations.getSummaryRes();

            //load combo with stockNo and Description for all stock
            for (int i = 0; i < ds.Tables["SR"].Rows.Count; i++)
                cboPBResID.Items.Add(ds.Tables[0].Rows[i][0].ToString().PadLeft(3, '0') +
                " " + ds.Tables[0].Rows[i][1].ToString());

        }

        private void BTMnuPayBill_Click(object sender, EventArgs e)
        {
            this.Hide();
            parent.Visible = true;
        }

        private void btnPBRes_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to pay bill this Reservation ID " + cboPBResID.SelectedItem, "Pay Bill Reservation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (choice == DialogResult.Yes)
            {
                //NO data to validate

                // Update data in Reservations File
                //Instantiate an instance of a Reservation with values in form controls
                aRes.setResStatus("P");
                aRes.setBillAmt(Convert.ToInt32(txtBillAmt.Text));

                //Invoke The PayBillRes() method
                aRes.PayBillRes();

                //display confirmation message
                MessageBox.Show("Reservation bill is paid", "Reservation bill is paid!!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //Reset UI
                cboPhone.SelectedIndex = 0;
                cboName.SelectedIndex = 0;
                grpPBResTables.Visible = false;
                cboPBResID.SelectedIndex = -1;
                cboPBArrTime.SelectedIndex = 0;
                cboPBPeople.SelectedIndex = 0;
                cboPBTables.SelectedIndex = 0;               
                txtBillAmt = null;
                cboPBResID.Focus();
                loadRes();
            }
        }
    }
}

