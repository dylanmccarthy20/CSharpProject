﻿
namespace RestResvSYS
{
    partial class frmRemoveTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRemoveTable));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BTMRemTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.exitTlStripRemTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.grpRemTable = new System.Windows.Forms.GroupBox();
            this.cboLoc = new System.Windows.Forms.ComboBox();
            this.cboPeople = new System.Windows.Forms.ComboBox();
            this.btnRemTbl = new System.Windows.Forms.Button();
            this.lblRemTblLocation = new System.Windows.Forms.Label();
            this.lblRemTblSize = new System.Windows.Forms.Label();
            this.lblRemTbl = new System.Windows.Forms.Label();
            this.cboRemTableNos = new System.Windows.Forms.ComboBox();
            this.oracleCommandBuilder1 = new Oracle.ManagedDataAccess.Client.OracleCommandBuilder();
            this.menuStrip1.SuspendLayout();
            this.grpRemTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMRemTbl,
            this.exitTlStripRemTbl});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1094, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // BTMRemTbl
            // 
            this.BTMRemTbl.Name = "BTMRemTbl";
            this.BTMRemTbl.Size = new System.Drawing.Size(181, 29);
            this.BTMRemTbl.Text = "Back To Main Menu";
            this.BTMRemTbl.Click += new System.EventHandler(this.BTMRemTbl_Click);
            // 
            // exitTlStripRemTbl
            // 
            this.exitTlStripRemTbl.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitTlStripRemTbl.Name = "exitTlStripRemTbl";
            this.exitTlStripRemTbl.Size = new System.Drawing.Size(55, 29);
            this.exitTlStripRemTbl.Text = "Exit";
            this.exitTlStripRemTbl.Click += new System.EventHandler(this.exitTlStripRemTbl_Click);
            // 
            // grpRemTable
            // 
            this.grpRemTable.Controls.Add(this.cboLoc);
            this.grpRemTable.Controls.Add(this.cboPeople);
            this.grpRemTable.Controls.Add(this.btnRemTbl);
            this.grpRemTable.Controls.Add(this.lblRemTblLocation);
            this.grpRemTable.Controls.Add(this.lblRemTblSize);
            this.grpRemTable.Location = new System.Drawing.Point(250, 161);
            this.grpRemTable.Name = "grpRemTable";
            this.grpRemTable.Size = new System.Drawing.Size(574, 344);
            this.grpRemTable.TabIndex = 3;
            this.grpRemTable.TabStop = false;
            this.grpRemTable.Text = "Please enter the details";
            this.grpRemTable.Visible = false;
            // 
            // cboLoc
            // 
            this.cboLoc.DropDownHeight = 1;
            this.cboLoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoc.FormattingEnabled = true;
            this.cboLoc.IntegralHeight = false;
            this.cboLoc.Location = new System.Drawing.Point(223, 164);
            this.cboLoc.Name = "cboLoc";
            this.cboLoc.Size = new System.Drawing.Size(158, 28);
            this.cboLoc.TabIndex = 15;
            // 
            // cboPeople
            // 
            this.cboPeople.DropDownHeight = 1;
            this.cboPeople.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPeople.FormattingEnabled = true;
            this.cboPeople.IntegralHeight = false;
            this.cboPeople.Location = new System.Drawing.Point(223, 114);
            this.cboPeople.Name = "cboPeople";
            this.cboPeople.Size = new System.Drawing.Size(158, 28);
            this.cboPeople.TabIndex = 14;
            // 
            // btnRemTbl
            // 
            this.btnRemTbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemTbl.Location = new System.Drawing.Point(239, 255);
            this.btnRemTbl.Name = "btnRemTbl";
            this.btnRemTbl.Size = new System.Drawing.Size(142, 46);
            this.btnRemTbl.TabIndex = 11;
            this.btnRemTbl.Text = "Submit";
            this.btnRemTbl.UseVisualStyleBackColor = true;
            this.btnRemTbl.Click += new System.EventHandler(this.btnRemTbl_Click);
            // 
            // lblRemTblLocation
            // 
            this.lblRemTblLocation.AutoSize = true;
            this.lblRemTblLocation.Location = new System.Drawing.Point(92, 167);
            this.lblRemTblLocation.Name = "lblRemTblLocation";
            this.lblRemTblLocation.Size = new System.Drawing.Size(78, 20);
            this.lblRemTblLocation.TabIndex = 6;
            this.lblRemTblLocation.Text = "Location: ";
            // 
            // lblRemTblSize
            // 
            this.lblRemTblSize.AutoSize = true;
            this.lblRemTblSize.Location = new System.Drawing.Point(34, 106);
            this.lblRemTblSize.Name = "lblRemTblSize";
            this.lblRemTblSize.Size = new System.Drawing.Size(136, 20);
            this.lblRemTblSize.TabIndex = 5;
            this.lblRemTblSize.Text = "Number of People";
            // 
            // lblRemTbl
            // 
            this.lblRemTbl.AutoSize = true;
            this.lblRemTbl.Location = new System.Drawing.Point(286, 89);
            this.lblRemTbl.Name = "lblRemTbl";
            this.lblRemTbl.Size = new System.Drawing.Size(114, 20);
            this.lblRemTbl.TabIndex = 7;
            this.lblRemTbl.Text = "Table number: ";
            // 
            // cboRemTableNos
            // 
            this.cboRemTableNos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRemTableNos.FormattingEnabled = true;
            this.cboRemTableNos.Location = new System.Drawing.Point(418, 85);
            this.cboRemTableNos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cboRemTableNos.Name = "cboRemTableNos";
            this.cboRemTableNos.Size = new System.Drawing.Size(247, 28);
            this.cboRemTableNos.TabIndex = 6;
            this.cboRemTableNos.SelectedIndexChanged += new System.EventHandler(this.cboRemTableNos_SelectedIndexChanged);
            // 
            // oracleCommandBuilder1
            // 
            this.oracleCommandBuilder1.CatalogLocation = System.Data.Common.CatalogLocation.End;
            this.oracleCommandBuilder1.CatalogSeparator = "@";
            // 
            // frmRemoveTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 537);
            this.Controls.Add(this.lblRemTbl);
            this.Controls.Add(this.cboRemTableNos);
            this.Controls.Add(this.grpRemTable);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmRemoveTable";
            this.Text = "Remove Table";
            this.Load += new System.EventHandler(this.frmRemoveTable_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpRemTable.ResumeLayout(false);
            this.grpRemTable.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BTMRemTbl;
        private System.Windows.Forms.ToolStripMenuItem exitTlStripRemTbl;
        private System.Windows.Forms.GroupBox grpRemTable;
        private System.Windows.Forms.Button btnRemTbl;
        private System.Windows.Forms.Label lblRemTblLocation;
        private System.Windows.Forms.Label lblRemTblSize;
        private System.Windows.Forms.Label lblRemTbl;
        private System.Windows.Forms.ComboBox cboRemTableNos;
        private Oracle.ManagedDataAccess.Client.OracleCommandBuilder oracleCommandBuilder1;
        private System.Windows.Forms.ComboBox cboLoc;
        private System.Windows.Forms.ComboBox cboPeople;
    }
}