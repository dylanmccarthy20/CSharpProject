﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestResvSYS
{
    public partial class frmRemoveTable : Form
    {
        frmMainMenu parent;
        Tables aTable = new Tables();
        Utility aUtility = new Utility();
        public frmRemoveTable()
        {
            InitializeComponent();
        }
        public frmRemoveTable(frmMainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }

        private void loadTables()
        {
            DataSet ds = Tables.getSummaryTables();

            //move records from ds into cboWidgets
            cboRemTableNos.Items.Clear();

            //load combo with stockNo and Description for all stock

            for (int i = 0; i < ds.Tables["TO"].Rows.Count; i++)
                cboRemTableNos.Items.Add(ds.Tables[0].Rows[i][0].ToString().PadLeft(3, '0') +
                " " + ds.Tables[0].Rows[i][1].ToString());

        }


        private void BTMRemTbl_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void btnRemTbl_Click(object sender, EventArgs e)
        {

            //NO data to validate

            // Update data in Tables File
            //Instantiate an instance of a Table with values in form controls
            aTable.setStatus("D");

            //Invoke The updateTable() method
            aTable.removeTable();

            //display confirmation message
            MessageBox.Show("Table is removed", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //reset UI
            grpRemTable.Visible = false;
            cboLoc.SelectedIndex = -1;
            cboPeople.SelectedIndex = -1;
            cboRemTableNos.Focus();
            loadTables();


        }

        private void frmRemoveTable_Load(object sender, EventArgs e)
        {
            loadTables();
        }

        private void exitTlStripRemTbl_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to exit the system", "Exiting The System", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (choice == DialogResult.Yes)
                Application.Exit();
        }

        private void cboRemTableNos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboRemTableNos.SelectedIndex == -1)
            {
                return;
            }

            Utility.LoadPeople(cboPeople);
            Utility.LoadLocs(cboLoc);

            aTable.getTable(Convert.ToInt32(cboRemTableNos.Text.Substring(0, 3)));

            //Set cboPeople to current value.
            cboPeople.SelectedIndex = 0;

            for (int i = 0; !(Convert.ToInt32(cboPeople.Text) == aTable.getSeatsNum()); i++)
            {
                cboPeople.SelectedIndex++;
            }

            //Setting cboLocation to current value

            cboLoc.SelectedIndex = 0;

            String locCode = aTable.getLocCode();

            for (int i = 0; !(cboLoc.Text.Substring(0, 1) == locCode); i++)
            {
                cboLoc.SelectedIndex++;
            }

            grpRemTable.Visible = true;

            aTable.getTable(Convert.ToInt32(cboRemTableNos.Text.Substring(0, 3)));
        }


    }
}
