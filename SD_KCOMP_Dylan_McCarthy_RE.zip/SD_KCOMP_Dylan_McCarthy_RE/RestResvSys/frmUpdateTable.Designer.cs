﻿
namespace RestResvSYS
{
    partial class frmUpdateTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpdateTable));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BTMUpdTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grpTable = new System.Windows.Forms.GroupBox();
            this.btnUpd = new System.Windows.Forms.Button();
            this.cboLoc = new System.Windows.Forms.ComboBox();
            this.cboPeople = new System.Windows.Forms.ComboBox();
            this.lblAddTblLocation = new System.Windows.Forms.Label();
            this.lblAddTblSize = new System.Windows.Forms.Label();
            this.cboTableNos = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.menuStrip1.SuspendLayout();
            this.grpTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMUpdTbl,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(811, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // BTMUpdTbl
            // 
            this.BTMUpdTbl.Name = "BTMUpdTbl";
            this.BTMUpdTbl.Size = new System.Drawing.Size(180, 29);
            this.BTMUpdTbl.Text = "Back to Main Menu";
            this.BTMUpdTbl.Click += new System.EventHandler(this.BTMUpdTbl_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(55, 29);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // grpTable
            // 
            this.grpTable.Controls.Add(this.btnUpd);
            this.grpTable.Controls.Add(this.cboLoc);
            this.grpTable.Controls.Add(this.cboPeople);
            this.grpTable.Controls.Add(this.lblAddTblLocation);
            this.grpTable.Controls.Add(this.lblAddTblSize);
            this.grpTable.Location = new System.Drawing.Point(43, 142);
            this.grpTable.Name = "grpTable";
            this.grpTable.Size = new System.Drawing.Size(719, 423);
            this.grpTable.TabIndex = 2;
            this.grpTable.TabStop = false;
            this.grpTable.Text = "Please enter the details";
            this.grpTable.Visible = false;
            // 
            // btnUpd
            // 
            this.btnUpd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpd.Location = new System.Drawing.Point(245, 295);
            this.btnUpd.Name = "btnUpd";
            this.btnUpd.Size = new System.Drawing.Size(142, 46);
            this.btnUpd.TabIndex = 11;
            this.btnUpd.Text = "Update";
            this.btnUpd.UseVisualStyleBackColor = true;
            this.btnUpd.Click += new System.EventHandler(this.btnUpd_Click);
            // 
            // cboLoc
            // 
            this.cboLoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoc.FormattingEnabled = true;
            this.cboLoc.Location = new System.Drawing.Point(214, 181);
            this.cboLoc.Name = "cboLoc";
            this.cboLoc.Size = new System.Drawing.Size(216, 28);
            this.cboLoc.TabIndex = 8;
            // 
            // cboPeople
            // 
            this.cboPeople.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPeople.FormattingEnabled = true;
            this.cboPeople.Location = new System.Drawing.Point(214, 108);
            this.cboPeople.Name = "cboPeople";
            this.cboPeople.Size = new System.Drawing.Size(216, 28);
            this.cboPeople.TabIndex = 7;
            // 
            // lblAddTblLocation
            // 
            this.lblAddTblLocation.AutoSize = true;
            this.lblAddTblLocation.Location = new System.Drawing.Point(86, 181);
            this.lblAddTblLocation.Name = "lblAddTblLocation";
            this.lblAddTblLocation.Size = new System.Drawing.Size(78, 20);
            this.lblAddTblLocation.TabIndex = 6;
            this.lblAddTblLocation.Text = "Location: ";
            // 
            // lblAddTblSize
            // 
            this.lblAddTblSize.AutoSize = true;
            this.lblAddTblSize.Location = new System.Drawing.Point(28, 108);
            this.lblAddTblSize.Name = "lblAddTblSize";
            this.lblAddTblSize.Size = new System.Drawing.Size(136, 20);
            this.lblAddTblSize.TabIndex = 5;
            this.lblAddTblSize.Text = "Number of People";
            // 
            // cboTableNos
            // 
            this.cboTableNos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTableNos.FormattingEnabled = true;
            this.cboTableNos.Location = new System.Drawing.Point(162, 75);
            this.cboTableNos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cboTableNos.Name = "cboTableNos";
            this.cboTableNos.Size = new System.Drawing.Size(247, 28);
            this.cboTableNos.TabIndex = 3;
            this.cboTableNos.SelectedIndexChanged += new System.EventHandler(this.cboTableNos_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Table number: ";
            // 
            // frmUpdateTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 665);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cboTableNos);
            this.Controls.Add(this.grpTable);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmUpdateTable";
            this.Text = "Update Table";
            this.Load += new System.EventHandler(this.frmUpdateTable_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpTable.ResumeLayout(false);
            this.grpTable.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BTMUpdTbl;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpTable;
        private System.Windows.Forms.Button btnUpd;
        private System.Windows.Forms.ComboBox cboLoc;
        private System.Windows.Forms.ComboBox cboPeople;
        private System.Windows.Forms.Label lblAddTblLocation;
        private System.Windows.Forms.Label lblAddTblSize;
        private System.Windows.Forms.ComboBox cboTableNos;
        private System.Windows.Forms.Label label1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}