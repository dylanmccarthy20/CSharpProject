﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestResvSYS
{
    
    public partial class frmUpdateTable : Form
    {
        frmMainMenu parent;
        Tables aTable = new Tables();
        Utility aUtility = new Utility();

        public frmUpdateTable(frmMainMenu Parent)
        {
            InitializeComponent();            
            parent = Parent;
        }
       

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to exit the system", "Exiting The System", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (choice == DialogResult.Yes)
                Application.Exit(); 
        }
        private void loadTables()
        {
              DataSet ds = Tables.getSummaryTables();

            //move records from ds into cboWidgets
            cboTableNos.Items.Clear();

            //load combo with stockNo and Description for all stock

            for (int i = 0; i < ds.Tables["TO"].Rows.Count; i++)
                cboTableNos.Items.Add(ds.Tables[0].Rows[i][0].ToString().PadLeft(3, '0') +
                " " + ds.Tables[0].Rows[i][1].ToString());
            
        }    

    private void frmUpdateTable_Load(object sender, EventArgs e)
        {
            //loads tables from database with the "A" status
            loadTables();
        } 

        private void cboTableNos_SelectedIndexChanged(object sender, EventArgs e)
        {
            //validates the data
            if (cboTableNos.SelectedIndex == -1)
            {
                return;
            }

            //loads data from the Utility Class methods for cboPeople and cboLoc
            cboPeople.Items.Clear();
            cboLoc.Items.Clear();
            Utility.LoadPeople(cboPeople);
            Utility.LoadLocs(cboLoc);

            //gets Table details where the details correspond with the matching tableNo
            aTable.getTable(Convert.ToInt32(cboTableNos.Text.Substring(0,3)));
            
            //Set cboPeople to current value.
            cboPeople.SelectedIndex = 0;
            
            //
            for(int i = 0; !(Convert.ToInt32(cboPeople.Text)==aTable.getSeatsNum());i++)
            {
                cboPeople.SelectedIndex++;
            }

            //Setting cboLocation to current value

            cboLoc.SelectedIndex = 0;

            //declaring the variable with a getter method

            String locCode=aTable.getLocCode();
            
            //for loop which finds the Location corresponding and it is shown on 0 index on the cboLoc
            for (int i = 0; !(cboLoc.Text.Substring(0,1) == locCode); i++)
            {
                cboLoc.SelectedIndex++;
            }

            //making the details visible
            grpTable.Visible = true;


            aTable.getTable(Convert.ToInt32(cboTableNos.Text.Substring(0, 3)));
        }
         
        private void btnUpd_Click(object sender, EventArgs e)
        {
            //validate data
            if (cboPeople.SelectedIndex == -1)
            {
                MessageBox.Show("The amount of people specified for this table was not defined", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (cboLoc.SelectedIndex == -1)
            {
                MessageBox.Show("The Location specified for this table was not defined", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Update data in Tables File
            //Instantiate an instance of a Table with values in form controls
               aTable.setLocCode(cboLoc.Text);
            aTable.setSeatsNum(Convert.ToInt32(cboPeople.Text));
            
            //Invoke The updateTable() method
            aTable.updateTable();

            //display confirmation message
            MessageBox.Show("Table is updated", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //reset UI
            grpTable.Visible = false;
            loadTables();
            cboTableNos.SelectedIndex = -1;
            cboTableNos.Focus();                                           
        }

        private void BTMUpdTbl_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }
                            
    }
}
