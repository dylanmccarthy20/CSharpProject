﻿
namespace RestResvSYS
{
    partial class frmYearlyRevenue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmYearlyRevenue));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BTMnuLocRevTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.exitTtlLocRevTbl = new System.Windows.Forms.ToolStripMenuItem();
            this.cboYear = new System.Windows.Forms.ComboBox();
            this.lblCIResID = new System.Windows.Forms.Label();
            this.chtYear = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chtYear)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMnuLocRevTbl,
            this.exitTtlLocRevTbl});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1133, 33);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // BTMnuLocRevTbl
            // 
            this.BTMnuLocRevTbl.Name = "BTMnuLocRevTbl";
            this.BTMnuLocRevTbl.Size = new System.Drawing.Size(180, 29);
            this.BTMnuLocRevTbl.Text = "Back to Main Menu";
            this.BTMnuLocRevTbl.Click += new System.EventHandler(this.BTMnuLocRevTbl_Click);
            // 
            // exitTtlLocRevTbl
            // 
            this.exitTtlLocRevTbl.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exitTtlLocRevTbl.Name = "exitTtlLocRevTbl";
            this.exitTtlLocRevTbl.Size = new System.Drawing.Size(55, 29);
            this.exitTtlLocRevTbl.Text = "Exit";
            this.exitTtlLocRevTbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.exitTtlLocRevTbl.Click += new System.EventHandler(this.exitTtlLocRevTbl_Click);
            // 
            // cboYear
            // 
            this.cboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboYear.FormattingEnabled = true;
            this.cboYear.Location = new System.Drawing.Point(410, 90);
            this.cboYear.Name = "cboYear";
            this.cboYear.Size = new System.Drawing.Size(142, 28);
            this.cboYear.TabIndex = 32;
            this.cboYear.SelectedIndexChanged += new System.EventHandler(this.cboYear_SelectedIndexChanged);
            // 
            // lblCIResID
            // 
            this.lblCIResID.AutoSize = true;
            this.lblCIResID.Location = new System.Drawing.Point(329, 93);
            this.lblCIResID.Name = "lblCIResID";
            this.lblCIResID.Size = new System.Drawing.Size(51, 20);
            this.lblCIResID.TabIndex = 31;
            this.lblCIResID.Text = "Year: ";
            // 
            // chtYear
            // 
            chartArea1.Name = "ChartArea1";
            this.chtYear.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chtYear.Legends.Add(legend1);
            this.chtYear.Location = new System.Drawing.Point(12, 142);
            this.chtYear.Name = "chtYear";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chtYear.Series.Add(series1);
            this.chtYear.Size = new System.Drawing.Size(1109, 463);
            this.chtYear.TabIndex = 33;
            this.chtYear.Visible = false;
            this.chtYear.Click += new System.EventHandler(this.chtYear_Click);
            // 
            // frmYearlyRevenue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1133, 705);
            this.Controls.Add(this.chtYear);
            this.Controls.Add(this.cboYear);
            this.Controls.Add(this.lblCIResID);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmYearlyRevenue";
            this.Text = resources.GetString("$this.Text");
            this.Load += new System.EventHandler(this.frmLocationRevTbl_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chtYear)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BTMnuLocRevTbl;
        private System.Windows.Forms.ToolStripMenuItem exitTtlLocRevTbl;
        private System.Windows.Forms.ComboBox cboYear;
        private System.Windows.Forms.Label lblCIResID;
        private System.Windows.Forms.DataVisualization.Charting.Chart chtYear;
    }
}