﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestResvSYS
{

    public partial class frmYearlyRevenue : Form
    {
        frmMainMenu parent;
        public frmYearlyRevenue()
        {
            InitializeComponent();
        }
        public frmYearlyRevenue(frmMainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }

        private void BTMnuLocRevTbl_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void frmLocationRevTbl_Load(object sender, EventArgs e)
        {
            //loads data from Utility class into the cboYears
            Utility.loadYears(cboYear);
        }

        public String getMonth(int month)
        {
            switch (month)
            {
                case 1:
                    {
                        return "JAN";
                    }
                case 2:
                    {
                        return "FEB";
                    }
                case 3:
                    {
                        return "MAR";
                    }
                case 4:
                    {
                        return "APR";
                    }
                case 5:
                    {
                        return "MAY";
                    }
                case 6:
                    {
                        return "JUN";
                    }
                case 7:
                    {
                        return "JUL";
                    }
                case 8:
                    {
                        return "AUG";
                    }
                case 9:
                    {
                        return "SEP";
                    }
                case 10:
                    {
                        return "OCT";
                    }
                case 11:
                    {
                        return "NOV";
                    }
                case 12:
                    {
                        return "DEC";
                    }
                default: return "OTH";


            }
        }

        private void exitTtlLocRevTbl_Click(object sender, EventArgs e)
        {
            var choice = MessageBox.Show("Are you sure you want to exit the system", "Exiting The System", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (choice == DialogResult.Yes)
                Application.Exit();
        }
        private void cboYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            chtYear.Visible = false;

            //getting data for the chart 
            DataTable dt = Reservations.getYearlyRevenue(cboYear.Text.Substring(2, 2));

            //loading the data into the chart
            //Array size 12 since there are 12 months in a year
            string[] Months = new string[12];            
            decimal[] Amounts = new decimal[12];

            //pre-fill each array; Months[] with month name; Amounts[] with zero values
            for (int i = 0; i < 12; i++)
            {
                Months[i] = getMonth(i+1);
                Amounts[i] = 0;
            }

            //Next, save the amounts returned in Query to the appropriate element in Amounts[]
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Amounts[Convert.ToInt32(dt.Rows[i][0]) - 1] = Convert.ToDecimal(dt.Rows[i][1]);
            }

            //Next, save the amounts returned in Query to the appropriate element in Amounts[]

            chtYear.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chtYear.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chtYear.Series[0].LegendText = "Income in €";
            chtYear.Series[0].Points.DataBindXY(Months, Amounts);
            chtYear.ChartAreas["ChartArea1"].AxisX.LabelStyle.Format = "C";
            chtYear.ChartAreas[0].AxisX.Interval = 1;
            //chtSales.Series[0].Points[0] = "XXX";
            chtYear.Series[0].Label = "#VALY";
            chtYear.Titles.Equals("Yearly Revenue");
            chtYear.ChartAreas[0].AxisX.LabelStyle.Format = "{0:0,}K";

            //displaying the chart
            chtYear.Visible = true;
           

            
        }

        private void chtYear_Click(object sender, EventArgs e)
        {

        }
    } 
}

