﻿
namespace RestResvSYS
{
    partial class frmYearlyTableCht
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmYearlyTableCht));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BTMTblResChrt = new System.Windows.Forms.ToolStripMenuItem();
            this.exittlStrpTblResChrt = new System.Windows.Forms.ToolStripMenuItem();
            this.cboYears = new System.Windows.Forms.ComboBox();
            this.lblYear = new System.Windows.Forms.Label();
            this.chtRes = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chtRes)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMTblResChrt,
            this.exittlStrpTblResChrt});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(863, 33);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // BTMTblResChrt
            // 
            this.BTMTblResChrt.Name = "BTMTblResChrt";
            this.BTMTblResChrt.Size = new System.Drawing.Size(181, 29);
            this.BTMTblResChrt.Text = "Back To Main Menu";
            this.BTMTblResChrt.Click += new System.EventHandler(this.BTMTblResChrt_Click);
            // 
            // exittlStrpTblResChrt
            // 
            this.exittlStrpTblResChrt.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.exittlStrpTblResChrt.Name = "exittlStrpTblResChrt";
            this.exittlStrpTblResChrt.Size = new System.Drawing.Size(55, 29);
            this.exittlStrpTblResChrt.Text = "Exit";
            this.exittlStrpTblResChrt.Click += new System.EventHandler(this.exittlStrpTblResChrt_Click);
            // 
            // cboYears
            // 
            this.cboYears.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboYears.FormattingEnabled = true;
            this.cboYears.Location = new System.Drawing.Point(360, 50);
            this.cboYears.Name = "cboYears";
            this.cboYears.Size = new System.Drawing.Size(121, 28);
            this.cboYears.TabIndex = 12;
            this.cboYears.SelectedIndexChanged += new System.EventHandler(this.cboYears_SelectedIndexChanged);
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(285, 53);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(47, 20);
            this.lblYear.TabIndex = 13;
            this.lblYear.Text = "Year:";
            // 
            // chtRes
            // 
            chartArea1.Name = "ChartArea1";
            this.chtRes.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chtRes.Legends.Add(legend1);
            this.chtRes.Location = new System.Drawing.Point(42, 110);
            this.chtRes.Name = "chtRes";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chtRes.Series.Add(series1);
            this.chtRes.Size = new System.Drawing.Size(773, 400);
            this.chtRes.TabIndex = 15;
            this.chtRes.Text = "chart2";
            // 
            // frmYearlyTableCht
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 534);
            this.Controls.Add(this.chtRes);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.cboYears);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmYearlyTableCht";
            this.Text = " ";
            this.Load += new System.EventHandler(this.frmTblResChrt_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chtRes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BTMTblResChrt;
        private System.Windows.Forms.ToolStripMenuItem exittlStrpTblResChrt;
        private System.Windows.Forms.ComboBox cboYears;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.DataVisualization.Charting.Chart chtRes;
    }
}